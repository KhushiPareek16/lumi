"""
Tests for services/ai_service.py

The Ollama client is fully mocked so no real LLM calls are made.
Tests verify that prompts are built correctly, responses are returned
as expected, and errors are wrapped in the right exception types.
"""

import json
import pytest
from unittest.mock import MagicMock, patch

from exceptions.errors import AIServiceError, InvalidQuizFormatError
from models.document import Document
from services.ai_service import AIService


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def sample_document() -> Document:
    return Document(
        filename="bio_notes.txt",
        content="Photosynthesis is the process by which plants convert sunlight into sugar.",
        topic="Biology",
    )


@pytest.fixture
def ai_service() -> AIService:
    return AIService(model_name="test-model")


def make_ollama_response(content: str) -> dict:
    """Build a fake ollama.chat() return value."""
    return {"message": {"content": content}}


# ---------------------------------------------------------------------------
# _call_ollama
# ---------------------------------------------------------------------------

class TestCallOllama:
    def test_returns_content_string(self, ai_service):
        with patch("services.ai_service.ollama.chat") as mock_chat:
            mock_chat.return_value = make_ollama_response("The answer is 42.")
            result = ai_service._call_ollama("system", "user")
        assert result == "The answer is 42."

    def test_wraps_exception_in_ai_service_error(self, ai_service):
        with patch("services.ai_service.ollama.chat") as mock_chat:
            mock_chat.side_effect = ConnectionError("Ollama not running")
            with pytest.raises(AIServiceError) as exc_info:
                ai_service._call_ollama("system", "user")
        assert "Ollama" in str(exc_info.value) or "AI service" in str(exc_info.value)

    def test_missing_key_raises_ai_service_error(self, ai_service):
        """If Ollama returns a response without the expected keys, raise AIServiceError."""
        with patch("services.ai_service.ollama.chat") as mock_chat:
            mock_chat.return_value = {"unexpected": "structure"}
            with pytest.raises(AIServiceError):
                ai_service._call_ollama("system", "user")


# ---------------------------------------------------------------------------
# answer_question
# ---------------------------------------------------------------------------

class TestAnswerQuestion:
    def test_returns_answer_string(self, ai_service, sample_document):
        with patch.object(ai_service, "_call_ollama", return_value="Photosynthesis makes sugar."):
            result = ai_service.answer_question(sample_document, "What is photosynthesis?")
        assert result == "Photosynthesis makes sugar."

    def test_eli10_mode_passes_instruction(self, ai_service, sample_document):
        """When eli10=True the system prompt should contain the ELI10 instruction."""
        captured_system = []

        def capture(sys_p, user_p):
            captured_system.append(sys_p)
            return "Simple answer."

        with patch.object(ai_service, "_call_ollama", side_effect=capture):
            ai_service.answer_question(sample_document, "What is photosynthesis?", eli10=True)

        assert "10 years old" in captured_system[0]

    def test_no_eli10_by_default(self, ai_service, sample_document):
        captured_system = []

        def capture(sys_p, user_p):
            captured_system.append(sys_p)
            return "Normal answer."

        with patch.object(ai_service, "_call_ollama", side_effect=capture):
            ai_service.answer_question(sample_document, "What is photosynthesis?")

        assert "10 years old" not in captured_system[0]

    def test_document_content_included_in_prompt(self, ai_service, sample_document):
        captured_user = []

        def capture(sys_p, user_p):
            captured_user.append(user_p)
            return "Answer."

        with patch.object(ai_service, "_call_ollama", side_effect=capture):
            ai_service.answer_question(sample_document, "Question?")

        assert "Photosynthesis" in captured_user[0]


# ---------------------------------------------------------------------------
# explain_concept
# ---------------------------------------------------------------------------

class TestExplainConcept:
    def test_returns_explanation(self, ai_service, sample_document):
        with patch.object(ai_service, "_call_ollama", return_value="It means making food from light."):
            result = ai_service.explain_concept(sample_document, "photosynthesis")
        assert "food from light" in result

    def test_eli10_instruction_present(self, ai_service, sample_document):
        captured = []

        def capture(sys_p, user_p):
            captured.append(sys_p)
            return "Explanation."

        with patch.object(ai_service, "_call_ollama", side_effect=capture):
            ai_service.explain_concept(sample_document, "photosynthesis", eli10=True)

        assert "10 years old" in captured[0]


# ---------------------------------------------------------------------------
# generate_quiz_raw
# ---------------------------------------------------------------------------

VALID_QUIZ_JSON = json.dumps([
    {
        "question_text": "What do plants use to make food?",
        "options": ["A. Water", "B. Sunlight", "C. Soil", "D. Wind"],
        "correct_answer": "B. Sunlight",
        "explanation": "Plants use sunlight in photosynthesis.",
    }
])


class TestGenerateQuizRaw:
    def test_returns_list_of_dicts(self, ai_service, sample_document):
        with patch.object(ai_service, "_call_ollama", return_value=VALID_QUIZ_JSON):
            result = ai_service.generate_quiz_raw(sample_document, 1)
        assert isinstance(result, list)
        assert len(result) == 1
        assert result[0]["question_text"] == "What do plants use to make food?"

    def test_strips_markdown_fences(self, ai_service, sample_document):
        fenced = f"```json\n{VALID_QUIZ_JSON}\n```"
        with patch.object(ai_service, "_call_ollama", return_value=fenced):
            result = ai_service.generate_quiz_raw(sample_document, 1)
        assert len(result) == 1

    def test_invalid_json_raises(self, ai_service, sample_document):
        with patch.object(ai_service, "_call_ollama", return_value="not valid json at all"):
            with pytest.raises(InvalidQuizFormatError):
                ai_service.generate_quiz_raw(sample_document, 1)

    def test_non_array_json_raises(self, ai_service, sample_document):
        with patch.object(ai_service, "_call_ollama", return_value='{"key": "value"}'):
            with pytest.raises(InvalidQuizFormatError):
                ai_service.generate_quiz_raw(sample_document, 1)

    def test_missing_fields_raises(self, ai_service, sample_document):
        bad_json = json.dumps([{"question_text": "Q?"}])  # missing options/correct_answer/explanation
        with patch.object(ai_service, "_call_ollama", return_value=bad_json):
            with pytest.raises(InvalidQuizFormatError):
                ai_service.generate_quiz_raw(sample_document, 1)

    def test_wrong_option_count_raises(self, ai_service, sample_document):
        bad_json = json.dumps([{
            "question_text": "Q?",
            "options": ["A", "B"],  # only 2 instead of 4
            "correct_answer": "A",
            "explanation": "Because A.",
        }])
        with patch.object(ai_service, "_call_ollama", return_value=bad_json):
            with pytest.raises(InvalidQuizFormatError):
                ai_service.generate_quiz_raw(sample_document, 1)


# ---------------------------------------------------------------------------
# generate_revision_plan
# ---------------------------------------------------------------------------

class TestGenerateRevisionPlan:
    def test_returns_schedule_string(self, ai_service, sample_document):
        with patch.object(ai_service, "_call_ollama", return_value="Day 1: Photosynthesis"):
            result = ai_service.generate_revision_plan(
                topics=["Photosynthesis"],
                document=sample_document,
            )
        assert "Day 1" in result

    def test_topics_included_in_prompt(self, ai_service, sample_document):
        captured_user = []

        def capture(sys_p, user_p):
            captured_user.append(user_p)
            return "Plan."

        with patch.object(ai_service, "_call_ollama", side_effect=capture):
            ai_service.generate_revision_plan(
                topics=["Photosynthesis", "Respiration"],
                document=sample_document,
            )

        assert "Photosynthesis" in captured_user[0]
        assert "Respiration" in captured_user[0]
