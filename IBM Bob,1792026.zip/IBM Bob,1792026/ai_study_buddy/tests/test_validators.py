"""
Tests for utils/validators.py

Each validator is tested for both the happy path (no exception) and
the expected failure path (correct exception raised).
"""

import pytest

from exceptions.errors import (
    DocumentNotLoadedError,
    FileTooLargeError,
    InvalidQuestionError,
    UnsupportedFileTypeError,
)
from utils.validators import (
    MAX_FILE_SIZE_BYTES,
    validate_document_loaded,
    validate_file_extension,
    validate_file_size,
    validate_num_questions,
    validate_question_text,
    validate_revision_days,
    validate_study_time,
    validate_topic_name,
)


# ---------------------------------------------------------------------------
# validate_file_extension
# ---------------------------------------------------------------------------

class TestValidateFileExtension:
    def test_txt_is_accepted(self):
        validate_file_extension("notes.txt")  # should not raise

    def test_pdf_is_accepted(self):
        validate_file_extension("chapter1.pdf")

    def test_docx_is_accepted(self):
        validate_file_extension("essay.docx")

    def test_uppercase_extension_is_accepted(self):
        validate_file_extension("NOTES.TXT")

    def test_jpg_raises(self):
        with pytest.raises(UnsupportedFileTypeError):
            validate_file_extension("photo.jpg")

    def test_no_extension_raises(self):
        with pytest.raises(UnsupportedFileTypeError):
            validate_file_extension("myfile")

    def test_mp4_raises(self):
        with pytest.raises(UnsupportedFileTypeError):
            validate_file_extension("lecture.mp4")


# ---------------------------------------------------------------------------
# validate_file_size
# ---------------------------------------------------------------------------

class TestValidateFileSize:
    def test_small_file_is_accepted(self):
        validate_file_size(b"hello world")  # well under 5 MB

    def test_exactly_at_limit_is_accepted(self):
        validate_file_size(b"x" * MAX_FILE_SIZE_BYTES)

    def test_one_byte_over_limit_raises(self):
        with pytest.raises(FileTooLargeError):
            validate_file_size(b"x" * (MAX_FILE_SIZE_BYTES + 1))

    def test_empty_bytes_are_accepted(self):
        validate_file_size(b"")  # zero bytes is valid (EmptyDocumentError handled separately)


# ---------------------------------------------------------------------------
# validate_question_text
# ---------------------------------------------------------------------------

class TestValidateQuestionText:
    def test_normal_question_is_accepted(self):
        validate_question_text("What is photosynthesis?")

    def test_minimum_length_question_is_accepted(self):
        validate_question_text("Why")  # exactly 3 chars

    def test_empty_string_raises(self):
        with pytest.raises(InvalidQuestionError):
            validate_question_text("")

    def test_whitespace_only_raises(self):
        with pytest.raises(InvalidQuestionError):
            validate_question_text("   ")

    def test_two_char_question_raises(self):
        with pytest.raises(InvalidQuestionError):
            validate_question_text("Hi")

    def test_none_raises(self):
        with pytest.raises(InvalidQuestionError):
            validate_question_text(None)  # type: ignore


# ---------------------------------------------------------------------------
# validate_topic_name
# ---------------------------------------------------------------------------

class TestValidateTopicName:
    def test_normal_topic_is_accepted(self):
        validate_topic_name("Photosynthesis")

    def test_topic_with_special_chars_is_accepted(self):
        validate_topic_name("C++ Pointers")

    def test_empty_topic_raises(self):
        with pytest.raises(ValueError):
            validate_topic_name("")

    def test_whitespace_only_raises(self):
        with pytest.raises(ValueError):
            validate_topic_name("   ")

    def test_none_raises(self):
        with pytest.raises(ValueError):
            validate_topic_name(None)  # type: ignore


# ---------------------------------------------------------------------------
# validate_num_questions
# ---------------------------------------------------------------------------

class TestValidateNumQuestions:
    def test_valid_range_accepted(self):
        for n in [1, 5, 10, 20]:
            validate_num_questions(n)

    def test_zero_raises(self):
        with pytest.raises(ValueError):
            validate_num_questions(0)

    def test_negative_raises(self):
        with pytest.raises(ValueError):
            validate_num_questions(-3)

    def test_twenty_one_raises(self):
        with pytest.raises(ValueError):
            validate_num_questions(21)

    def test_float_raises(self):
        with pytest.raises(ValueError):
            validate_num_questions(5.0)  # type: ignore


# ---------------------------------------------------------------------------
# validate_document_loaded
# ---------------------------------------------------------------------------

class TestValidateDocumentLoaded:
    def test_none_raises(self):
        with pytest.raises(DocumentNotLoadedError):
            validate_document_loaded(None)

    def test_non_none_object_passes(self):
        validate_document_loaded(object())  # any non-None passes


# ---------------------------------------------------------------------------
# validate_study_time
# ---------------------------------------------------------------------------

class TestValidateStudyTime:
    def test_positive_float_accepted(self):
        validate_study_time(2.0)

    def test_positive_int_accepted(self):
        validate_study_time(3)

    def test_zero_raises(self):
        with pytest.raises(ValueError):
            validate_study_time(0)

    def test_negative_raises(self):
        with pytest.raises(ValueError):
            validate_study_time(-1.0)

    def test_string_raises(self):
        with pytest.raises(ValueError):
            validate_study_time("two")  # type: ignore


# ---------------------------------------------------------------------------
# validate_revision_days
# ---------------------------------------------------------------------------

class TestValidateRevisionDays:
    def test_positive_int_accepted(self):
        validate_revision_days(7)

    def test_one_day_accepted(self):
        validate_revision_days(1)

    def test_zero_raises(self):
        with pytest.raises(ValueError):
            validate_revision_days(0)

    def test_negative_raises(self):
        with pytest.raises(ValueError):
            validate_revision_days(-1)

    def test_float_raises(self):
        with pytest.raises(ValueError):
            validate_revision_days(3.5)  # type: ignore
