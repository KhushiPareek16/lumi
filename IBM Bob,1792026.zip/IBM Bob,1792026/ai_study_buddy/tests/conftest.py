"""
conftest.py — shared pytest fixtures for all test modules.
"""

import sys
import os

# Ensure the project root (ai_study_buddy/) is on the path so imports work
# when running pytest from inside the ai_study_buddy/ directory.
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
