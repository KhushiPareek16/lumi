"""
Tests for services/quiz_service.py

AIService is mocked so no real Ollama calls are made.
Persistence is mocked to avoid file I/O.
"""

import pytest
from unittest.mock import MagicMock

from models.document import Document
from models.quiz import Question, Quiz
from services.quiz_service import QuizService
from exceptions.errors import DocumentNotLoadedError


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def sample_document() -> Document:
    return Document(
        filename="notes.txt",
        content="Photosynthesis converts sunlight to sugar.",
        topic="Biology",
    )


RAW_QUESTIONS = [
    {
        "question_text": "What does photosynthesis produce?",
        "options": ["A. Oxygen only", "B. Sugar", "C. Carbon dioxide", "D. Water"],
        "correct_answer": "B. Sugar",
        "explanation": "Plants produce sugar via photosynthesis.",
    },
    {
        "question_text": "What energy source do plants use?",
        "options": ["A. Wind", "B. Fire", "C. Sunlight", "D. Sound"],
        "correct_answer": "C. Sunlight",
        "explanation": "Plants capture sunlight as their energy source.",
    },
]


@pytest.fixture
def mock_ai_service() -> MagicMock:
    ai = MagicMock()
    ai.generate_quiz_raw.return_value = RAW_QUESTIONS
    return ai


@pytest.fixture
def mock_persistence() -> MagicMock:
    return MagicMock()


@pytest.fixture
def quiz_service(mock_ai_service, mock_persistence) -> QuizService:
    return QuizService(ai_service=mock_ai_service, persistence=mock_persistence)


# ---------------------------------------------------------------------------
# create_quiz
# ---------------------------------------------------------------------------

class TestCreateQuiz:
    def test_returns_quiz_with_correct_question_count(self, quiz_service, sample_document):
        quiz = quiz_service.create_quiz(sample_document, num_questions=2)
        assert isinstance(quiz, Quiz)
        assert len(quiz.questions) == 2

    def test_quiz_topic_matches_document_topic(self, quiz_service, sample_document):
        quiz = quiz_service.create_quiz(sample_document, num_questions=2)
        assert quiz.topic == "Biology"

    def test_quiz_source_document_matches_filename(self, quiz_service, sample_document):
        quiz = quiz_service.create_quiz(sample_document, num_questions=2)
        assert quiz.source_document == "notes.txt"

    def test_questions_are_question_objects(self, quiz_service, sample_document):
        quiz = quiz_service.create_quiz(sample_document, num_questions=2)
        for q in quiz.questions:
            assert isinstance(q, Question)

    def test_none_document_raises(self, quiz_service):
        with pytest.raises(DocumentNotLoadedError):
            quiz_service.create_quiz(None, num_questions=5)

    def test_invalid_num_questions_raises(self, quiz_service, sample_document):
        with pytest.raises(ValueError):
            quiz_service.create_quiz(sample_document, num_questions=0)

    def test_too_many_questions_raises(self, quiz_service, sample_document):
        with pytest.raises(ValueError):
            quiz_service.create_quiz(sample_document, num_questions=21)


# ---------------------------------------------------------------------------
# save_quiz
# ---------------------------------------------------------------------------

class TestSaveQuiz:
    def test_save_calls_persistence(self, quiz_service, mock_persistence, sample_document):
        quiz = quiz_service.create_quiz(sample_document, num_questions=2)
        quiz_service.save_quiz(quiz)
        mock_persistence.save_quiz.assert_called_once_with(quiz)


# ---------------------------------------------------------------------------
# score_quiz
# ---------------------------------------------------------------------------

class TestScoreQuiz:
    def _make_quiz(self) -> Quiz:
        """Create a Quiz with two known questions for scoring tests."""
        q1 = Question(
            question_text="Q1",
            options=["A. Yes", "B. No", "C. Maybe", "D. Never"],
            correct_answer="A. Yes",
            explanation="",
        )
        q2 = Question(
            question_text="Q2",
            options=["A. Red", "B. Blue", "C. Green", "D. Yellow"],
            correct_answer="C. Green",
            explanation="",
        )
        return Quiz(topic="Test", source_document="test.txt", questions=[q1, q2])

    def test_all_correct_returns_full_score(self, quiz_service):
        quiz = self._make_quiz()
        answers = {0: "A. Yes", 1: "C. Green"}
        result = quiz_service.score_quiz(quiz, answers)
        assert result["score"] == 2
        assert result["total"] == 2
        assert result["percent"] == 100
        assert result["results"] == [True, True]

    def test_all_wrong_returns_zero_score(self, quiz_service):
        quiz = self._make_quiz()
        answers = {0: "B. No", 1: "A. Red"}
        result = quiz_service.score_quiz(quiz, answers)
        assert result["score"] == 0
        assert result["percent"] == 0
        assert result["results"] == [False, False]

    def test_partial_score(self, quiz_service):
        quiz = self._make_quiz()
        answers = {0: "A. Yes", 1: "A. Red"}  # Q1 correct, Q2 wrong
        result = quiz_service.score_quiz(quiz, answers)
        assert result["score"] == 1
        assert result["total"] == 2
        assert result["percent"] == 50
        assert result["results"] == [True, False]

    def test_unanswered_question_counts_as_wrong(self, quiz_service):
        quiz = self._make_quiz()
        answers = {0: "A. Yes"}  # Q2 not answered
        result = quiz_service.score_quiz(quiz, answers)
        assert result["score"] == 1
        assert result["results"][1] is False
