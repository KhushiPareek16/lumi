"""
Tests for services/revision_service.py

AIService and Persistence are mocked to avoid real I/O or LLM calls.
"""

import pytest
from unittest.mock import MagicMock

from models.document import Document
from models.revision_plan import RevisionPlan
from services.revision_service import RevisionService
from exceptions.errors import DocumentNotLoadedError, NoTopicsSelectedError


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def sample_document() -> Document:
    return Document(
        filename="notes.txt",
        content="Photosynthesis converts sunlight to sugar.",
        topic="Biology",
    )


@pytest.fixture
def mock_ai_service() -> MagicMock:
    ai = MagicMock()
    ai.generate_revision_plan.return_value = (
        "Day 1: Photosynthesis\nDay 2: Respiration"
    )
    return ai


@pytest.fixture
def mock_persistence() -> MagicMock:
    return MagicMock()


@pytest.fixture
def revision_service(mock_ai_service, mock_persistence) -> RevisionService:
    return RevisionService(ai_service=mock_ai_service, persistence=mock_persistence)


# ---------------------------------------------------------------------------
# create_revision_plan
# ---------------------------------------------------------------------------

class TestCreateRevisionPlan:
    def test_returns_revision_plan(self, revision_service, sample_document):
        plan = revision_service.create_revision_plan(
            topics=["Photosynthesis"],
            document=sample_document,
        )
        assert isinstance(plan, RevisionPlan)

    def test_plan_contains_topics(self, revision_service, sample_document):
        plan = revision_service.create_revision_plan(
            topics=["Photosynthesis", "Respiration"],
            document=sample_document,
        )
        assert "Photosynthesis" in plan.topics
        assert "Respiration" in plan.topics

    def test_plan_schedule_is_from_ai(self, revision_service, sample_document):
        plan = revision_service.create_revision_plan(
            topics=["Photosynthesis"],
            document=sample_document,
        )
        assert "Day 1" in plan.schedule

    def test_empty_topics_raises(self, revision_service, sample_document):
        with pytest.raises(NoTopicsSelectedError):
            revision_service.create_revision_plan(
                topics=[],
                document=sample_document,
            )

    def test_all_blank_topics_raises(self, revision_service, sample_document):
        with pytest.raises(NoTopicsSelectedError):
            revision_service.create_revision_plan(
                topics=["   ", ""],
                document=sample_document,
            )

    def test_none_document_raises(self, revision_service):
        with pytest.raises(DocumentNotLoadedError):
            revision_service.create_revision_plan(
                topics=["Topic"],
                document=None,
            )

    def test_invalid_study_hours_raises(self, revision_service, sample_document):
        with pytest.raises(ValueError):
            revision_service.create_revision_plan(
                topics=["Topic"],
                document=sample_document,
                study_hours_per_day=-1,
            )

    def test_invalid_num_days_raises(self, revision_service, sample_document):
        with pytest.raises(ValueError):
            revision_service.create_revision_plan(
                topics=["Topic"],
                document=sample_document,
                num_days=0,
            )

    def test_blank_topics_are_stripped_before_ai_call(
        self, revision_service, sample_document, mock_ai_service
    ):
        """Blank entries in the topics list should be stripped before calling AI."""
        revision_service.create_revision_plan(
            topics=["  Photosynthesis  ", "  "],
            document=sample_document,
        )
        call_kwargs = mock_ai_service.generate_revision_plan.call_args
        sent_topics = call_kwargs[1]["topics"] if call_kwargs[1] else call_kwargs[0][0]
        assert "Photosynthesis" in sent_topics
        assert any(t.strip() == "" for t in sent_topics) is False


# ---------------------------------------------------------------------------
# save_plan
# ---------------------------------------------------------------------------

class TestSavePlan:
    def test_save_calls_persistence(
        self, revision_service, mock_persistence, sample_document
    ):
        plan = revision_service.create_revision_plan(
            topics=["Photosynthesis"],
            document=sample_document,
        )
        revision_service.save_plan(plan)
        mock_persistence.save_plan.assert_called_once_with(plan)
