"""
Tests for storage/persistence.py

Uses pytest's tmp_path fixture to write to a temporary directory
so tests don't touch the real data/history.json file.
"""

import json
import os
import pytest

from models.quiz import Question, Quiz
from models.revision_plan import RevisionPlan
from storage.persistence import Persistence


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def persistence(tmp_path) -> Persistence:
    """Return a Persistence instance pointing at a temp file."""
    filepath = str(tmp_path / "history.json")
    return Persistence(filepath=filepath)


def make_quiz(topic: str = "Biology") -> Quiz:
    q = Question(
        question_text="What is photosynthesis?",
        options=["A. X", "B. Y", "C. Z", "D. W"],
        correct_answer="A. X",
        explanation="Because X.",
    )
    return Quiz(topic=topic, source_document="notes.txt", questions=[q])


def make_plan(topics: list[str] | None = None) -> RevisionPlan:
    return RevisionPlan(
        topics=topics or ["Photosynthesis"],
        schedule="Day 1: Photosynthesis",
    )


# ---------------------------------------------------------------------------
# Auto-creation of history file
# ---------------------------------------------------------------------------

class TestFileAutoCreation:
    def test_file_created_on_init(self, tmp_path):
        filepath = str(tmp_path / "new_history.json")
        assert not os.path.exists(filepath)
        Persistence(filepath=filepath)
        assert os.path.exists(filepath)

    def test_file_initialised_with_empty_lists(self, tmp_path):
        filepath = str(tmp_path / "new_history.json")
        Persistence(filepath=filepath)
        with open(filepath) as f:
            data = json.load(f)
        assert data == {"quizzes": [], "revision_plans": []}


# ---------------------------------------------------------------------------
# Quiz persistence
# ---------------------------------------------------------------------------

class TestSaveAndGetQuizzes:
    def test_save_quiz_persists_to_file(self, persistence):
        quiz = make_quiz()
        persistence.save_quiz(quiz)
        with open(persistence.filepath) as f:
            data = json.load(f)
        assert len(data["quizzes"]) == 1
        assert data["quizzes"][0]["topic"] == "Biology"

    def test_get_quizzes_returns_list(self, persistence):
        persistence.save_quiz(make_quiz("Biology"))
        quizzes = persistence.get_quizzes()
        assert len(quizzes) == 1
        assert isinstance(quizzes[0], Quiz)

    def test_multiple_quizzes_saved_and_retrieved(self, persistence):
        persistence.save_quiz(make_quiz("Biology"))
        persistence.save_quiz(make_quiz("Chemistry"))
        quizzes = persistence.get_quizzes()
        assert len(quizzes) == 2

    def test_quizzes_returned_newest_first(self, persistence):
        persistence.save_quiz(make_quiz("Biology"))
        persistence.save_quiz(make_quiz("Chemistry"))
        quizzes = persistence.get_quizzes()
        # Newest (Chemistry) should be first
        assert quizzes[0].topic == "Chemistry"

    def test_empty_history_returns_empty_list(self, persistence):
        assert persistence.get_quizzes() == []

    def test_round_trip_preserves_questions(self, persistence):
        quiz = make_quiz()
        persistence.save_quiz(quiz)
        loaded = persistence.get_quizzes()[0]
        assert len(loaded.questions) == 1
        assert loaded.questions[0].question_text == "What is photosynthesis?"


# ---------------------------------------------------------------------------
# Revision plan persistence
# ---------------------------------------------------------------------------

class TestSaveAndGetPlans:
    def test_save_plan_persists_to_file(self, persistence):
        plan = make_plan()
        persistence.save_plan(plan)
        with open(persistence.filepath) as f:
            data = json.load(f)
        assert len(data["revision_plans"]) == 1

    def test_get_plans_returns_list(self, persistence):
        persistence.save_plan(make_plan())
        plans = persistence.get_plans()
        assert len(plans) == 1
        assert isinstance(plans[0], RevisionPlan)

    def test_plans_returned_newest_first(self, persistence):
        persistence.save_plan(make_plan(["Topic A"]))
        persistence.save_plan(make_plan(["Topic B"]))
        plans = persistence.get_plans()
        assert plans[0].topics == ["Topic B"]

    def test_empty_history_returns_empty_list(self, persistence):
        assert persistence.get_plans() == []

    def test_round_trip_preserves_schedule(self, persistence):
        plan = make_plan()
        persistence.save_plan(plan)
        loaded = persistence.get_plans()[0]
        assert loaded.schedule == "Day 1: Photosynthesis"


# ---------------------------------------------------------------------------
# Corrupt file recovery
# ---------------------------------------------------------------------------

class TestCorruptFileRecovery:
    def test_corrupt_json_returns_empty_store(self, tmp_path):
        filepath = str(tmp_path / "corrupt.json")
        with open(filepath, "w") as f:
            f.write("this is not valid json {{{")
        p = Persistence(filepath=filepath)
        # Should not raise; should return empty lists
        assert p.get_quizzes() == []
        assert p.get_plans() == []
