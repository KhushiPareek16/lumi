"""
Tests for services/document_service.py

Uses in-memory BytesIO objects to simulate uploaded files without
requiring real files on disk.  PDF and DOCX extraction is mocked
so tests don't need actual pdfplumber / python-docx calls.
"""

import io
import pytest
from unittest.mock import MagicMock, patch

from exceptions.errors import EmptyDocumentError, FileTooLargeError, UnsupportedFileTypeError
from models.document import Document
from services.document_service import DocumentService, MAX_CONTENT_CHARS


def make_file(content: bytes, name: str) -> io.BytesIO:
    """Helper: create a BytesIO with a .name attribute."""
    f = io.BytesIO(content)
    f.name = name
    return f


class TestDocumentServiceTxt:
    """Tests for plain-text file loading."""

    def setup_method(self):
        self.service = DocumentService()

    def test_load_txt_returns_document(self):
        f = make_file(b"Hello, this is my study note.", "notes.txt")
        doc = self.service.load_document(f, topic="Test Topic")
        assert isinstance(doc, Document)
        assert "Hello" in doc.content
        assert doc.filename == "notes.txt"
        assert doc.topic == "Test Topic"

    def test_load_txt_strips_whitespace_topic(self):
        f = make_file(b"Some content here.", "notes.txt")
        doc = self.service.load_document(f, topic="  Biology  ")
        assert doc.topic == "Biology"

    def test_load_empty_txt_raises(self):
        f = make_file(b"   ", "empty.txt")
        with pytest.raises(EmptyDocumentError):
            self.service.load_document(f, topic="Topic")

    def test_unsupported_extension_raises(self):
        f = make_file(b"data", "image.jpg")
        with pytest.raises(UnsupportedFileTypeError):
            self.service.load_document(f, topic="Topic")

    def test_file_too_large_raises(self):
        large_content = b"x" * (5 * 1024 * 1024 + 1)
        f = make_file(large_content, "big.txt")
        with pytest.raises(FileTooLargeError):
            self.service.load_document(f, topic="Topic")

    def test_latin1_fallback_decoding(self):
        """Files with non-UTF-8 bytes should fall back to latin-1."""
        latin_bytes = "Ça va? Résumé".encode("latin-1")
        f = make_file(latin_bytes, "latin.txt")
        doc = self.service.load_document(f, topic="French")
        assert doc.content  # should not raise; content has text


class TestDocumentServicePdf:
    """Tests for PDF loading (pdfplumber is mocked)."""

    def setup_method(self):
        self.service = DocumentService()

    def test_load_pdf_returns_document(self):
        with patch("services.document_service.pdfplumber") as mock_plumber:
            mock_page = MagicMock()
            mock_page.extract_text.return_value = "Page one text."
            mock_pdf = MagicMock()
            mock_pdf.pages = [mock_page]
            mock_plumber.open.return_value.__enter__.return_value = mock_pdf

            f = make_file(b"%PDF-fake", "lecture.pdf")
            doc = self.service.load_document(f, topic="Lecture")

        assert "Page one text." in doc.content
        assert doc.filename == "lecture.pdf"

    def test_empty_pdf_raises(self):
        """PDF with no extractable text (e.g. scanned image) should raise."""
        with patch("services.document_service.pdfplumber") as mock_plumber:
            mock_page = MagicMock()
            mock_page.extract_text.return_value = None
            mock_pdf = MagicMock()
            mock_pdf.pages = [mock_page]
            mock_plumber.open.return_value.__enter__.return_value = mock_pdf

            f = make_file(b"%PDF-fake", "scanned.pdf")
            with pytest.raises(EmptyDocumentError):
                self.service.load_document(f, topic="Scanned")


class TestDocumentServiceDocx:
    """Tests for DOCX loading (python-docx is mocked)."""

    def setup_method(self):
        self.service = DocumentService()

    def test_load_docx_returns_document(self):
        mock_para = MagicMock()
        mock_para.text = "First paragraph of the document."
        with patch("services.document_service.DocxDocument") as MockDocx:
            mock_doc_obj = MagicMock()
            mock_doc_obj.paragraphs = [mock_para]
            MockDocx.return_value = mock_doc_obj

            f = make_file(b"PK fake docx bytes", "essay.docx")
            doc = self.service.load_document(f, topic="Essay")

        assert "First paragraph" in doc.content

    def test_empty_docx_raises(self):
        with patch("services.document_service.DocxDocument") as MockDocx:
            mock_doc_obj = MagicMock()
            mock_doc_obj.paragraphs = []
            MockDocx.return_value = mock_doc_obj

            f = make_file(b"PK empty", "empty.docx")
            with pytest.raises(EmptyDocumentError):
                self.service.load_document(f, topic="Topic")


class TestTruncateContent:
    """Tests for the static truncate_content helper."""

    def test_short_content_unchanged(self):
        text = "Short text."
        result = DocumentService.truncate_content(text)
        assert result == text

    def test_long_content_is_truncated(self):
        long_text = "A" * (MAX_CONTENT_CHARS + 5000)
        result = DocumentService.truncate_content(long_text)
        assert len(result) <= MAX_CONTENT_CHARS + 200  # small buffer for notice

    def test_truncation_notice_added(self):
        long_text = "Word. " * 3000
        result = DocumentService.truncate_content(long_text)
        assert "truncated" in result.lower()

    def test_custom_max_chars_respected(self):
        text = "Hello world. Another sentence here."
        result = DocumentService.truncate_content(text, max_chars=15)
        assert len(result) <= 15 + 100  # buffer for the appended notice
