"""
Persistence layer.

Saves and loads Quiz and RevisionPlan objects to/from a local
JSON file (data/history.json).

No other module should read or write the JSON file directly —
all persistence goes through this class.
"""

import json
import os
from typing import List

from models.quiz import Quiz
from models.revision_plan import RevisionPlan

# Default path relative to the project root (ai_study_buddy/)
DEFAULT_HISTORY_PATH = os.path.join(
    os.path.dirname(os.path.dirname(__file__)), "data", "history.json"
)

_EMPTY_STORE: dict = {"quizzes": [], "revision_plans": []}


class Persistence:
    """
    Simple JSON-file persistence for quiz and revision-plan history.

    Parameters
    ----------
    filepath:
        Path to the JSON history file.  Created automatically if it
        does not exist.
    """

    def __init__(self, filepath: str = DEFAULT_HISTORY_PATH) -> None:
        self.filepath = filepath
        # Ensure the data directory and file exist on startup
        os.makedirs(os.path.dirname(self.filepath), exist_ok=True)
        if not os.path.exists(self.filepath):
            self._save(_EMPTY_STORE.copy())

    # ------------------------------------------------------------------
    # Quiz persistence
    # ------------------------------------------------------------------

    def save_quiz(self, quiz: Quiz) -> None:
        """Append *quiz* to the history file."""
        data = self._load()
        data["quizzes"].append(quiz.to_dict())
        self._save(data)

    def get_quizzes(self) -> List[Quiz]:
        """
        Return all saved quizzes, newest first.

        Returns
        -------
        list[Quiz]
            May be empty if no quizzes have been saved yet.
        """
        data = self._load()
        quizzes = [Quiz.from_dict(q) for q in data.get("quizzes", [])]
        return list(reversed(quizzes))  # newest first

    # ------------------------------------------------------------------
    # Revision plan persistence
    # ------------------------------------------------------------------

    def save_plan(self, plan: RevisionPlan) -> None:
        """Append *plan* to the history file."""
        data = self._load()
        data["revision_plans"].append(plan.to_dict())
        self._save(data)

    def get_plans(self) -> List[RevisionPlan]:
        """
        Return all saved revision plans, newest first.

        Returns
        -------
        list[RevisionPlan]
            May be empty if no plans have been saved yet.
        """
        data = self._load()
        plans = [RevisionPlan.from_dict(p) for p in data.get("revision_plans", [])]
        return list(reversed(plans))  # newest first

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _load(self) -> dict:
        """Read and return the JSON history file as a Python dict."""
        try:
            with open(self.filepath, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, FileNotFoundError):
            # If the file is corrupt or missing, start fresh
            return _EMPTY_STORE.copy()

    def _save(self, data: dict) -> None:
        """Write *data* to the JSON history file with indentation."""
        with open(self.filepath, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
