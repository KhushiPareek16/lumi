"""
AI Study Buddy — Streamlit UI entry point.

Run with:
    streamlit run app.py

This file handles ALL user interaction and display.
Business logic lives in services/. This file should contain
no AI calls, file I/O, or complex logic of its own.
"""

import sys
import os

# Make sure Python can find our project modules when run from inside
# the ai_study_buddy/ folder.
sys.path.insert(0, os.path.dirname(__file__))

import streamlit as st

from exceptions.errors import (
    AIServiceError,
    DocumentNotLoadedError,
    EmptyDocumentError,
    FileTooLargeError,
    InvalidQuizFormatError,
    InvalidQuestionError,
    NoTopicsSelectedError,
    UnsupportedFileTypeError,
)
from models.document import Document
from services.ai_service import AIService
from services.document_service import DocumentService
from services.quiz_service import QuizService
from services.revision_service import RevisionService
from storage.persistence import Persistence

# ---------------------------------------------------------------------------
# Page configuration
# ---------------------------------------------------------------------------
st.set_page_config(
    page_title="AI Study Buddy",
    page_icon="📚",
    layout="centered",
)

# ---------------------------------------------------------------------------
# Service initialisation (cached so they are created once per session)
# ---------------------------------------------------------------------------

@st.cache_resource
def get_services():
    """Create and return all service singletons."""
    persistence = Persistence()
    ai_service = AIService()
    document_service = DocumentService()
    quiz_service = QuizService(ai_service=ai_service, persistence=persistence)
    revision_service = RevisionService(ai_service=ai_service, persistence=persistence)
    return persistence, ai_service, document_service, quiz_service, revision_service


persistence, ai_service, document_service, quiz_service, revision_service = get_services()

# ---------------------------------------------------------------------------
# Session state initialisation
# ---------------------------------------------------------------------------

def init_session_state() -> None:
    """Initialise all session state keys to their default values."""
    defaults = {
        "document": None,          # Active Document object
        "eli10": False,            # ELI-10 mode toggle
        "topics": [],              # List of topic strings for revision plan
        "current_quiz": None,      # Most recently generated Quiz
        "quiz_answers": {},        # {question_index: chosen_option_string}
        "quiz_submitted": False,   # Whether the student has submitted the quiz
        "quiz_score": None,        # Scoring result dict
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


init_session_state()

# ---------------------------------------------------------------------------
# Sidebar
# ---------------------------------------------------------------------------

with st.sidebar:
    st.title("📚 AI Study Buddy")
    st.caption("Your personal AI-powered learning assistant")
    st.divider()

    page = st.radio(
        "Navigate to",
        options=[
            "📤 Upload Notes",
            "❓ Ask a Doubt",
            "💡 Explain Simply",
            "📝 Generate Quiz",
            "📅 Revision Plan",
            "🕑 History",
        ],
        label_visibility="collapsed",
    )

    st.divider()

    # ELI10 toggle
    st.session_state.eli10 = st.toggle(
        "🧒 Explain Like I'm 10",
        value=st.session_state.eli10,
        help="When ON, all explanations and answers use very simple language.",
    )
    if st.session_state.eli10:
        st.info("ELI10 mode is **ON**")

    st.divider()

    # Show active document name
    if st.session_state.document:
        st.success(f"📄 **{st.session_state.document.filename}**")
        st.caption(f"Topic: {st.session_state.document.topic}")
    else:
        st.warning("No document loaded")

# ---------------------------------------------------------------------------
# Helper: document guard banner
# ---------------------------------------------------------------------------

def require_document() -> bool:
    """
    Show a warning and return False if no document is loaded.
    Return True if a document is available.
    """
    if st.session_state.document is None:
        st.warning(
            "⚠️ No study material loaded. "
            "Please go to **📤 Upload Notes** and upload a document first."
        )
        return False
    return True


# ---------------------------------------------------------------------------
# Page: Upload Notes
# ---------------------------------------------------------------------------

if page == "📤 Upload Notes":
    st.header("📤 Upload Your Study Notes")
    st.write(
        "Upload a `.txt`, `.pdf`, or `.docx` file. "
        "The app will extract the text and use it to answer your questions."
    )

    topic_input = st.text_input(
        "Subject / Topic",
        placeholder="e.g. Biology Chapter 3 — Photosynthesis",
        help="Give your notes a topic label so the AI has context.",
    )

    uploaded_file = st.file_uploader(
        "Choose a file",
        type=["txt", "pdf", "docx"],
        help="Maximum file size: 5 MB",
    )

    if uploaded_file is not None:
        if st.button("📥 Load Document", type="primary"):
            if not topic_input.strip():
                st.error("Please enter a subject / topic before loading.")
            else:
                with st.spinner("Reading your document…"):
                    try:
                        doc: Document = document_service.load_document(
                            uploaded_file, topic=topic_input
                        )
                        st.session_state.document = doc
                        # Reset quiz state when a new document is loaded
                        st.session_state.current_quiz = None
                        st.session_state.quiz_answers = {}
                        st.session_state.quiz_submitted = False
                        st.session_state.quiz_score = None
                        st.success(
                            f"✅ **{doc.filename}** loaded successfully! "
                            f"({len(doc.content):,} characters extracted)"
                        )
                    except UnsupportedFileTypeError as e:
                        st.error(f"❌ Unsupported file type: {e}")
                    except FileTooLargeError as e:
                        st.error(f"❌ File too large: {e}")
                    except EmptyDocumentError as e:
                        st.error(f"❌ Empty document: {e}")
                    except Exception as e:
                        st.error(f"❌ An unexpected error occurred: {e}")

    # Preview loaded document
    if st.session_state.document:
        with st.expander("🔍 Preview extracted text (first 600 characters)"):
            st.text(st.session_state.document.content[:600])

# ---------------------------------------------------------------------------
# Page: Ask a Doubt
# ---------------------------------------------------------------------------

elif page == "❓ Ask a Doubt":
    st.header("❓ Ask a Doubt")
    st.write("Type your question and get an answer based on your uploaded notes.")

    if st.session_state.eli10:
        st.info("🧒 ELI10 mode is ON — answers will use simple language.")

    if require_document():
        question = st.text_area(
            "Your question",
            placeholder="e.g. What is the role of chlorophyll in photosynthesis?",
            height=100,
        )

        if st.button("🔍 Get Answer", type="primary"):
            try:
                from utils.validators import validate_question_text
                validate_question_text(question)

                with st.spinner("Thinking…"):
                    answer = ai_service.answer_question(
                        document=st.session_state.document,
                        question=question,
                        eli10=st.session_state.eli10,
                    )

                st.subheader("Answer")
                st.markdown(answer)

            except InvalidQuestionError as e:
                st.error(f"❌ {e}")
            except AIServiceError as e:
                st.error(f"❌ AI service error: {e}")
            except Exception as e:
                st.error(f"❌ Something went wrong: {e}")

# ---------------------------------------------------------------------------
# Page: Explain Simply
# ---------------------------------------------------------------------------

elif page == "💡 Explain Simply":
    st.header("💡 Explain Simply")
    st.write(
        "Enter a concept or term from your notes and get a clear explanation."
    )

    if st.session_state.eli10:
        st.info("🧒 ELI10 mode is ON — explanations will use very simple language and analogies.")

    if require_document():
        concept = st.text_input(
            "Concept to explain",
            placeholder="e.g. Mitosis",
        )

        if st.button("💡 Explain", type="primary"):
            if not concept.strip():
                st.error("❌ Please enter a concept to explain.")
            else:
                with st.spinner("Generating explanation…"):
                    try:
                        explanation = ai_service.explain_concept(
                            document=st.session_state.document,
                            concept=concept,
                            eli10=st.session_state.eli10,
                        )
                        st.subheader("Explanation")
                        st.markdown(explanation)
                    except AIServiceError as e:
                        st.error(f"❌ AI service error: {e}")
                    except Exception as e:
                        st.error(f"❌ Something went wrong: {e}")

# ---------------------------------------------------------------------------
# Page: Generate Quiz
# ---------------------------------------------------------------------------

elif page == "📝 Generate Quiz":
    st.header("📝 Generate Quiz")
    st.write("Generate multiple-choice questions from your uploaded notes.")

    if require_document():
        num_q = st.number_input(
            "Number of questions",
            min_value=1,
            max_value=20,
            value=5,
            step=1,
        )

        if st.button("⚡ Generate Quiz", type="primary"):
            with st.spinner("Generating quiz questions…"):
                try:
                    quiz = quiz_service.create_quiz(
                        document=st.session_state.document,
                        num_questions=int(num_q),
                    )
                    quiz_service.save_quiz(quiz)
                    st.session_state.current_quiz = quiz
                    st.session_state.quiz_answers = {}
                    st.session_state.quiz_submitted = False
                    st.session_state.quiz_score = None
                    st.success(
                        f"✅ Quiz generated with {len(quiz.questions)} questions!"
                    )
                except (AIServiceError, InvalidQuizFormatError) as e:
                    st.error(f"❌ {e}")
                except Exception as e:
                    st.error(f"❌ Something went wrong: {e}")

        # Render the active quiz
        quiz = st.session_state.current_quiz
        if quiz:
            st.divider()
            st.subheader(f"Quiz: {quiz.topic}")

            with st.form("quiz_form"):
                for i, question in enumerate(quiz.questions):
                    st.markdown(f"**Q{i + 1}. {question.question_text}**")

                    # Use a sentinel "Not answered" so we know when unanswered
                    options_with_prompt = ["— select an answer —"] + question.options
                    chosen = st.radio(
                        label=f"q_{i}",
                        options=options_with_prompt,
                        index=0,
                        label_visibility="collapsed",
                        key=f"quiz_q_{i}",
                    )
                    # Store the real answer (not the sentinel)
                    if chosen != "— select an answer —":
                        st.session_state.quiz_answers[i] = chosen

                    st.write("")  # spacing

                submitted = st.form_submit_button("✅ Submit Quiz", type="primary")

            if submitted:
                # Check all questions answered
                unanswered = [
                    i + 1
                    for i in range(len(quiz.questions))
                    if i not in st.session_state.quiz_answers
                ]
                if unanswered:
                    st.warning(
                        f"⚠️ Please answer all questions before submitting. "
                        f"Unanswered: Q{', Q'.join(str(n) for n in unanswered)}"
                    )
                else:
                    score_result = quiz_service.score_quiz(
                        quiz, st.session_state.quiz_answers
                    )
                    st.session_state.quiz_score = score_result
                    st.session_state.quiz_submitted = True

            # Show results after submission
            if st.session_state.quiz_submitted and st.session_state.quiz_score:
                result = st.session_state.quiz_score
                st.divider()
                st.subheader("📊 Your Score")

                col1, col2 = st.columns(2)
                col1.metric("Score", f"{result['score']} / {result['total']}")
                col2.metric("Percentage", f"{result['percent']}%")

                if result["percent"] >= 80:
                    st.success("🎉 Excellent work!")
                elif result["percent"] >= 50:
                    st.info("👍 Good effort! Review the explanations below.")
                else:
                    st.warning("📖 Keep studying! Check the explanations below.")

                st.divider()
                st.subheader("Answers & Explanations")
                for i, question in enumerate(quiz.questions):
                    correct = result["results"][i]
                    icon = "✅" if correct else "❌"
                    with st.expander(f"{icon} Q{i + 1}: {question.question_text}"):
                        student_answer = st.session_state.quiz_answers.get(i, "No answer")
                        st.write(f"**Your answer:** {student_answer}")
                        st.write(f"**Correct answer:** {question.correct_answer}")
                        if question.explanation:
                            st.info(f"💡 {question.explanation}")

# ---------------------------------------------------------------------------
# Page: Revision Plan
# ---------------------------------------------------------------------------

elif page == "📅 Revision Plan":
    st.header("📅 Personalised Revision Plan")
    st.write(
        "Add the topics you want to revise, set your study schedule, "
        "and let the AI build a plan for you."
    )

    if require_document():
        # --- Topic management ---
        st.subheader("Topics to Revise")
        col_input, col_btn = st.columns([4, 1])
        new_topic = col_input.text_input(
            "Add a topic",
            placeholder="e.g. Photosynthesis",
            label_visibility="collapsed",
        )
        if col_btn.button("➕ Add"):
            if new_topic.strip():
                if new_topic.strip() not in st.session_state.topics:
                    st.session_state.topics.append(new_topic.strip())
                    st.rerun()
                else:
                    st.warning("That topic is already in the list.")
            else:
                st.error("Topic name cannot be empty.")

        if st.session_state.topics:
            for idx, t in enumerate(st.session_state.topics):
                col_t, col_del = st.columns([6, 1])
                col_t.markdown(f"• **{t}**")
                if col_del.button("🗑️", key=f"del_topic_{idx}"):
                    st.session_state.topics.pop(idx)
                    st.rerun()
        else:
            st.caption("No topics added yet.")

        st.divider()

        # --- Study schedule inputs ---
        st.subheader("Study Schedule")
        col_h, col_d = st.columns(2)
        hours_per_day = col_h.number_input(
            "Hours available per day",
            min_value=0.5,
            max_value=12.0,
            value=2.0,
            step=0.5,
        )
        num_days = col_d.number_input(
            "Number of revision days",
            min_value=1,
            max_value=30,
            value=7,
            step=1,
        )

        st.divider()

        if st.button("📅 Generate Revision Plan", type="primary"):
            with st.spinner("Building your personalised revision plan…"):
                try:
                    plan = revision_service.create_revision_plan(
                        topics=st.session_state.topics,
                        document=st.session_state.document,
                        study_hours_per_day=float(hours_per_day),
                        num_days=int(num_days),
                    )
                    revision_service.save_plan(plan)
                    st.success("✅ Revision plan generated and saved!")
                    st.subheader("Your Revision Plan")
                    st.markdown(plan.schedule)
                except NoTopicsSelectedError as e:
                    st.error(f"❌ {e}")
                except AIServiceError as e:
                    st.error(f"❌ AI service error: {e}")
                except ValueError as e:
                    st.error(f"❌ Invalid input: {e}")
                except Exception as e:
                    st.error(f"❌ Something went wrong: {e}")

# ---------------------------------------------------------------------------
# Page: History
# ---------------------------------------------------------------------------

elif page == "🕑 History":
    st.header("🕑 History")
    st.write("View your previously generated quizzes and revision plans.")

    quizzes = persistence.get_quizzes()
    plans = persistence.get_plans()

    if not quizzes and not plans:
        st.info(
            "No history yet. Generate a quiz or revision plan and it will appear here."
        )
    else:
        # --- Quizzes ---
        if quizzes:
            st.subheader(f"📝 Quizzes ({len(quizzes)})")
            for quiz in quizzes:
                with st.expander(
                    f"**{quiz.topic}** — {len(quiz.questions)} questions "
                    f"| {quiz.created_at[:10]}"
                ):
                    st.caption(f"Source: {quiz.source_document}")
                    for i, q in enumerate(quiz.questions):
                        st.markdown(f"**Q{i + 1}. {q.question_text}**")
                        for opt in q.options:
                            marker = "✅ " if opt == q.correct_answer else "   "
                            st.write(f"{marker}{opt}")
                        if q.explanation:
                            st.caption(f"💡 {q.explanation}")
                        st.write("")

        # --- Revision Plans ---
        if plans:
            st.subheader(f"📅 Revision Plans ({len(plans)})")
            for plan in plans:
                topics_str = ", ".join(plan.topics)
                with st.expander(
                    f"**{topics_str[:60]}{'…' if len(topics_str) > 60 else ''}** "
                    f"| {plan.created_at[:10]}"
                ):
                    st.markdown(plan.schedule)
