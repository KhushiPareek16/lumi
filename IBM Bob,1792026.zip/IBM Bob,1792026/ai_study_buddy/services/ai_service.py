"""
AI service — all communication with the Ollama local LLM.

No other module should call Ollama directly.  Every AI feature
(Q&A, explain, quiz generation, revision plan) goes through this
class so prompts and error handling stay in one place.

Configuration
-------------
Set the environment variable OLLAMA_MODEL to override the default
model name, e.g.::

    $env:OLLAMA_MODEL = "mistral"   # Windows PowerShell
    export OLLAMA_MODEL=mistral      # macOS / Linux

The default is ``llama3``.
"""

import json
import os
from typing import Any

import ollama

from exceptions.errors import AIServiceError, InvalidQuizFormatError
from models.document import Document
from services.document_service import DocumentService


class AIService:
    """
    Wraps all Ollama interactions.

    Parameters
    ----------
    model_name:
        The Ollama model to use.  Defaults to the ``OLLAMA_MODEL``
        environment variable, falling back to ``"llama3"``.
    """

    def __init__(self, model_name: str | None = None) -> None:
        self.model_name: str = (
            model_name
            or os.environ.get("OLLAMA_MODEL", "llama3")
        )

    # ------------------------------------------------------------------
    # Public methods — one per AI feature
    # ------------------------------------------------------------------

    def answer_question(
        self, document: Document, question: str, eli10: bool = False
    ) -> str:
        """
        Answer *question* using the content of *document*.

        Parameters
        ----------
        document:
            The active study document.
        question:
            The student's question.
        eli10:
            If True, ask the LLM to explain at a 10-year-old level.

        Returns
        -------
        str
            The LLM's answer as plain text.
        """
        eli10_instruction = (
            "Explain your answer as if the student is 10 years old. "
            "Use simple words, short sentences, and a fun analogy if helpful."
            if eli10
            else ""
        )

        system_prompt = (
            "You are a helpful study assistant. "
            "Answer the student's question using ONLY the provided study material. "
            "If the answer is not found in the material, say clearly: "
            "'I could not find that information in the provided study material.' "
            f"{eli10_instruction}"
        )

        user_prompt = (
            f"--- STUDY MATERIAL ---\n"
            f"{DocumentService.truncate_content(document.content)}\n"
            f"--- END OF MATERIAL ---\n\n"
            f"Question: {question}"
        )

        return self._call_ollama(system_prompt, user_prompt)

    def explain_concept(
        self, document: Document, concept: str, eli10: bool = False
    ) -> str:
        """
        Explain *concept* using the content of *document*.

        Parameters
        ----------
        document:
            The active study document.
        concept:
            The concept or term to explain.
        eli10:
            If True, explain at a 10-year-old level with an analogy.

        Returns
        -------
        str
            The LLM's explanation as plain text.
        """
        eli10_instruction = (
            "Explain as if the student is 10 years old. "
            "Use a simple, concrete analogy."
            if eli10
            else "Be clear and concise."
        )

        system_prompt = (
            "You are a patient tutor. "
            "Explain the concept using ONLY information from the provided study material. "
            f"{eli10_instruction}"
        )

        user_prompt = (
            f"--- STUDY MATERIAL ---\n"
            f"{DocumentService.truncate_content(document.content)}\n"
            f"--- END OF MATERIAL ---\n\n"
            f"Concept to explain: {concept}"
        )

        return self._call_ollama(system_prompt, user_prompt)

    def generate_quiz_raw(
        self, document: Document, num_questions: int
    ) -> list[dict[str, Any]]:
        """
        Ask the LLM to generate *num_questions* multiple-choice questions.

        Returns
        -------
        list[dict]
            A list of raw question dicts parsed from the LLM's JSON
            response.  Each dict has the keys:
            ``question_text``, ``options``, ``correct_answer``,
            ``explanation``.

        Raises
        ------
        InvalidQuizFormatError
            If the LLM response cannot be parsed as valid JSON or does
            not match the expected structure.
        """
        system_prompt = (
            "You are a quiz generator. "
            f"Generate exactly {num_questions} multiple-choice questions "
            "based ONLY on the provided study material.\n\n"
            "Return your response as a valid JSON array and NOTHING ELSE. "
            "No explanation. No markdown fences. No extra text. "
            "Use this exact structure:\n"
            '[\n'
            '  {\n'
            '    "question_text": "...",\n'
            '    "options": ["A. ...", "B. ...", "C. ...", "D. ..."],\n'
            '    "correct_answer": "A. ...",\n'
            '    "explanation": "Brief explanation of why this is correct."\n'
            '  }\n'
            ']'
        )

        user_prompt = (
            f"--- STUDY MATERIAL ---\n"
            f"{DocumentService.truncate_content(document.content)}\n"
            f"--- END OF MATERIAL ---"
        )

        raw_response = self._call_ollama(system_prompt, user_prompt)
        return self._parse_quiz_json(raw_response, num_questions)

    def generate_revision_plan(
        self,
        topics: list[str],
        document: Document,
        study_hours_per_day: float = 2.0,
        num_days: int = 7,
    ) -> str:
        """
        Generate a plain-text revision plan for the given *topics*.

        Parameters
        ----------
        topics:
            List of topic names to revise.
        document:
            The active study document (used as context).
        study_hours_per_day:
            How many hours per day the student can study.
        num_days:
            Total number of days in the plan.

        Returns
        -------
        str
            A day-by-day revision schedule as plain text.
        """
        topics_str = ", ".join(topics)

        system_prompt = (
            "You are a study planner. "
            "Create a simple, realistic day-by-day revision plan for a student "
            "based ONLY on the topics and study material provided. "
            "Keep the language encouraging and easy to understand. "
            "Format the plan with a clear section for each day."
        )

        user_prompt = (
            f"Topics to revise: {topics_str}\n"
            f"Available study time: {study_hours_per_day} hours per day\n"
            f"Number of days: {num_days}\n\n"
            f"--- STUDY MATERIAL ---\n"
            f"{DocumentService.truncate_content(document.content)}\n"
            f"--- END OF MATERIAL ---"
        )

        return self._call_ollama(system_prompt, user_prompt)

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _call_ollama(self, system_prompt: str, user_prompt: str) -> str:
        """
        Send a chat request to Ollama and return the response text.

        Raises
        ------
        AIServiceError
            Wraps any exception raised by the Ollama client.
        """
        try:
            response = ollama.chat(
                model=self.model_name,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
            )
            # ollama.chat returns a dict-like object; content is nested
            return response["message"]["content"].strip()
        except KeyError as exc:
            raise AIServiceError(
                "Received an unexpected response structure from Ollama."
            ) from exc
        except Exception as exc:
            raise AIServiceError(
                f"Could not reach the AI service. "
                f"Make sure Ollama is running and the model '{self.model_name}' is available. "
                f"Detail: {exc}"
            ) from exc

    @staticmethod
    def _parse_quiz_json(raw: str, expected_count: int) -> list[dict[str, Any]]:
        """
        Parse *raw* as JSON and validate the quiz structure.

        Strips common LLM formatting artefacts (markdown code fences)
        before parsing.

        Raises
        ------
        InvalidQuizFormatError
            If the JSON is invalid or the structure doesn't match.
        """
        # Strip markdown fences if the model wrapped its output
        clean = raw.strip()
        if clean.startswith("```"):
            lines = clean.splitlines()
            # Remove first and last fence lines
            clean = "\n".join(lines[1:-1] if lines[-1].strip() == "```" else lines[1:])

        try:
            data = json.loads(clean)
        except json.JSONDecodeError as exc:
            raise InvalidQuizFormatError(
                f"The AI returned quiz content that could not be parsed as JSON. "
                f"Try generating again. Detail: {exc}"
            ) from exc

        if not isinstance(data, list):
            raise InvalidQuizFormatError(
                "Expected a JSON array of questions but got a different structure."
            )

        required_keys = {"question_text", "options", "correct_answer", "explanation"}
        for i, item in enumerate(data):
            missing = required_keys - item.keys()
            if missing:
                raise InvalidQuizFormatError(
                    f"Question {i + 1} is missing required fields: {missing}"
                )
            if not isinstance(item["options"], list) or len(item["options"]) != 4:
                raise InvalidQuizFormatError(
                    f"Question {i + 1} must have exactly 4 options."
                )

        return data
