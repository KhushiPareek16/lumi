"""
Revision plan service.

Coordinates revision plan generation.
Calls AIService and wraps the result into a RevisionPlan model object.
"""

from models.document import Document
from models.revision_plan import RevisionPlan
from services.ai_service import AIService
from exceptions.errors import NoTopicsSelectedError
from utils.validators import (
    validate_document_loaded,
    validate_study_time,
    validate_revision_days,
)


class RevisionService:
    """
    Manages the full revision-plan lifecycle: create → save.

    Parameters
    ----------
    ai_service:
        An AIService instance used to generate the revision plan.
    persistence:
        A Persistence instance used to save plans to history.
    """

    def __init__(self, ai_service: AIService, persistence: object) -> None:
        self._ai = ai_service
        self._persistence = persistence

    def create_revision_plan(
        self,
        topics: list[str],
        document: Document,
        study_hours_per_day: float = 2.0,
        num_days: int = 7,
    ) -> RevisionPlan:
        """
        Generate a personalised revision plan.

        Parameters
        ----------
        topics:
            Non-empty list of topic names to include in the plan.
        document:
            The active study document (used as LLM context).
        study_hours_per_day:
            Hours the student can study each day.
        num_days:
            Total days to cover in the plan.

        Returns
        -------
        RevisionPlan
            A fully populated RevisionPlan.

        Raises
        ------
        NoTopicsSelectedError
            If *topics* is empty.
        DocumentNotLoadedError
            If *document* is None.
        ValueError
            If *study_hours_per_day* or *num_days* are invalid.
        AIServiceError
            Propagated from AIService if the call fails.
        """
        if not topics:
            raise NoTopicsSelectedError(
                "Please add at least one topic before generating a revision plan."
            )

        validate_document_loaded(document)
        validate_study_time(study_hours_per_day)
        validate_revision_days(num_days)

        # Strip blanks from topic list before sending to AI
        clean_topics = [t.strip() for t in topics if t.strip()]
        if not clean_topics:
            raise NoTopicsSelectedError(
                "All entered topics were blank. Please enter valid topic names."
            )

        schedule: str = self._ai.generate_revision_plan(
            topics=clean_topics,
            document=document,
            study_hours_per_day=study_hours_per_day,
            num_days=num_days,
        )

        plan = RevisionPlan(
            topics=clean_topics,
            schedule=schedule,
        )
        return plan

    def save_plan(self, plan: RevisionPlan) -> None:
        """Persist *plan* to the history store."""
        self._persistence.save_plan(plan)
