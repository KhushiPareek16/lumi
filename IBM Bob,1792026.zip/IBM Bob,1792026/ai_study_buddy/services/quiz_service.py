"""
Quiz service.

Coordinates quiz creation and scoring.
Calls AIService to get raw question data, wraps it into model
objects, handles persistence, and scores student answers.
"""

from models.document import Document
from models.quiz import Question, Quiz
from services.ai_service import AIService
from utils.validators import validate_document_loaded, validate_num_questions


class QuizService:
    """
    Manages the full quiz lifecycle: create → save → score.

    Parameters
    ----------
    ai_service:
        An AIService instance used to generate quiz questions.
    persistence:
        A Persistence instance used to save quizzes to history.
    """

    def __init__(self, ai_service: AIService, persistence: object) -> None:
        self._ai = ai_service
        self._persistence = persistence

    def create_quiz(self, document: Document, num_questions: int) -> Quiz:
        """
        Generate a new Quiz from *document*.

        Parameters
        ----------
        document:
            The active study document.
        num_questions:
            How many questions to generate (1–20).

        Returns
        -------
        Quiz
            A fully populated Quiz ready to be displayed and scored.

        Raises
        ------
        DocumentNotLoadedError
            If *document* is None.
        ValueError
            If *num_questions* is out of range.
        InvalidQuizFormatError / AIServiceError
            Propagated from AIService if generation or parsing fails.
        """
        validate_document_loaded(document)
        validate_num_questions(num_questions)

        raw_questions: list[dict] = self._ai.generate_quiz_raw(document, num_questions)

        questions = [
            Question(
                question_text=q["question_text"],
                options=q["options"],
                correct_answer=q["correct_answer"],
                explanation=q.get("explanation", ""),
            )
            for q in raw_questions
        ]

        quiz = Quiz(
            topic=document.topic,
            source_document=document.filename,
            questions=questions,
        )
        return quiz

    def save_quiz(self, quiz: Quiz) -> None:
        """Persist *quiz* to the history store."""
        self._persistence.save_quiz(quiz)

    def score_quiz(self, quiz: Quiz, answers: dict[int, str]) -> dict:
        """
        Score the student's answers against *quiz*.

        Parameters
        ----------
        quiz:
            The Quiz being scored.
        answers:
            Mapping of question index (0-based) to the student's
            chosen option string (must match one of the 4 options).

        Returns
        -------
        dict with keys:
            ``score``   — number of correct answers (int)
            ``total``   — total number of questions (int)
            ``results`` — list[bool], True where the answer was correct
            ``percent`` — rounded percentage score (int)
        """
        results: list[bool] = []
        for i, question in enumerate(quiz.questions):
            chosen = answers.get(i, "")
            results.append(chosen == question.correct_answer)

        score = sum(results)
        total = len(quiz.questions)
        percent = round((score / total) * 100) if total > 0 else 0

        return {
            "score": score,
            "total": total,
            "results": results,
            "percent": percent,
        }
