"""
Document processing service.

Responsible for reading uploaded files and extracting plain text.
Supports .txt, .pdf (via pdfplumber), and .docx (via python-docx).

This module has NO Streamlit imports — it is pure business logic.
"""

import io
from datetime import datetime, timezone
from typing import BinaryIO, Union

import pdfplumber
from docx import Document as DocxDocument

from exceptions.errors import EmptyDocumentError, UnsupportedFileTypeError
from models.document import Document
from utils.validators import (
    validate_file_extension,
    validate_file_size,
)

# Maximum characters sent to the LLM to avoid exceeding context windows.
MAX_CONTENT_CHARS: int = 12_000


class DocumentService:
    """
    Handles file reading and text extraction.

    Usage::

        service = DocumentService()
        doc = service.load_document(uploaded_file, topic="Biology Chapter 3")
    """

    def load_document(
        self, file_obj: Union[BinaryIO, io.BytesIO], topic: str
    ) -> Document:
        """
        Read *file_obj*, extract its text, and return a Document.

        Parameters
        ----------
        file_obj:
            A file-like object with a ``name`` attribute (e.g. from
            Streamlit's ``st.file_uploader``).
        topic:
            The subject / topic label entered by the student.

        Returns
        -------
        Document
            A populated Document ready to be stored in session state.

        Raises
        ------
        UnsupportedFileTypeError
            If the file extension is not .txt, .pdf, or .docx.
        FileTooLargeError
            If the file content exceeds 5 MB.
        EmptyDocumentError
            If no readable text can be extracted.
        """
        filename: str = file_obj.name
        validate_file_extension(filename)

        raw_bytes: bytes = file_obj.read()
        validate_file_size(raw_bytes)

        # Dispatch to the correct extractor
        lower = filename.lower()
        if lower.endswith(".txt"):
            content = self._extract_txt(raw_bytes)
        elif lower.endswith(".pdf"):
            content = self._extract_pdf(raw_bytes)
        elif lower.endswith(".docx"):
            content = self._extract_docx(raw_bytes)
        else:
            # Should never reach here after validate_file_extension, but be safe
            raise UnsupportedFileTypeError(f"Unsupported file type: {filename}")

        if not content or not content.strip():
            raise EmptyDocumentError(
                "The uploaded file appears to be empty or contains no readable text. "
                "If this is a scanned PDF, try uploading a text-based version."
            )

        content = self.truncate_content(content)

        return Document(
            filename=filename,
            content=content,
            topic=topic.strip(),
            uploaded_at=datetime.now(timezone.utc).isoformat(),
        )

    # ------------------------------------------------------------------
    # Private extraction helpers
    # ------------------------------------------------------------------

    def _extract_txt(self, raw_bytes: bytes) -> str:
        """Decode raw bytes from a .txt file as UTF-8 (with fallback)."""
        try:
            return raw_bytes.decode("utf-8")
        except UnicodeDecodeError:
            return raw_bytes.decode("latin-1", errors="replace")

    def _extract_pdf(self, raw_bytes: bytes) -> str:
        """Extract text from all pages of a PDF using pdfplumber."""
        pages_text: list[str] = []
        with pdfplumber.open(io.BytesIO(raw_bytes)) as pdf:
            for page in pdf.pages:
                text = page.extract_text()
                if text:
                    pages_text.append(text)
        return "\n".join(pages_text)

    def _extract_docx(self, raw_bytes: bytes) -> str:
        """Extract paragraph text from a .docx file using python-docx."""
        doc = DocxDocument(io.BytesIO(raw_bytes))
        paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
        return "\n".join(paragraphs)

    # ------------------------------------------------------------------
    # Content trimming
    # ------------------------------------------------------------------

    @staticmethod
    def truncate_content(content: str, max_chars: int = MAX_CONTENT_CHARS) -> str:
        """
        Trim *content* to at most *max_chars* characters.

        Trims at the last sentence boundary ('. ') within the limit so
        the text sent to the LLM ends cleanly rather than mid-word.
        """
        if len(content) <= max_chars:
            return content

        truncated = content[:max_chars]
        # Try to end at the last sentence boundary
        last_period = truncated.rfind(". ")
        if last_period > max_chars // 2:
            truncated = truncated[: last_period + 1]

        return truncated + "\n\n[Content truncated to fit AI context window]"
