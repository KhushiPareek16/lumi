"""
Topic data model.

Represents a single study topic that the student wants to revise.
Topics are collected in session state and passed to the revision
plan generator.
"""

from datetime import datetime, timezone
from dataclasses import dataclass, field


@dataclass
class Topic:
    """A study topic the student wants to revise."""

    name: str
    """Human-readable topic name, e.g. 'Photosynthesis'."""

    added_at: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
    """ISO-8601 UTC timestamp of when this topic was added."""

    def to_dict(self) -> dict:
        """Serialise to a plain Python dict."""
        return {"name": self.name, "added_at": self.added_at}

    @classmethod
    def from_dict(cls, data: dict) -> "Topic":
        """Reconstruct a Topic from a plain Python dict."""
        return cls(
            name=data["name"],
            added_at=data.get("added_at", datetime.now(timezone.utc).isoformat()),
        )
