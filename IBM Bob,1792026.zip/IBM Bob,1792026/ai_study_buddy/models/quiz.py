"""
Quiz and Question data models.

A Quiz contains a list of multiple-choice Question objects.
Both support serialisation to/from plain dicts so they can be
saved in history.json by the persistence layer.
"""

import uuid
from datetime import datetime, timezone
from dataclasses import dataclass, field
from typing import List


@dataclass
class Question:
    """A single multiple-choice question with four options and a correct answer."""

    question_text: str
    """The question being asked."""

    options: List[str]
    """Exactly four answer options, e.g. ['A. Paris', 'B. London', ...]."""

    correct_answer: str
    """The full text of the correct option, matching one entry in `options`."""

    explanation: str
    """Brief explanation of why the correct answer is right."""

    def to_dict(self) -> dict:
        """Serialise to a plain Python dict."""
        return {
            "question_text": self.question_text,
            "options": self.options,
            "correct_answer": self.correct_answer,
            "explanation": self.explanation,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Question":
        """Reconstruct a Question from a plain Python dict."""
        return cls(
            question_text=data["question_text"],
            options=data["options"],
            correct_answer=data["correct_answer"],
            explanation=data.get("explanation", ""),
        )


@dataclass
class Quiz:
    """A complete quiz generated from a study document."""

    topic: str
    """The subject/topic this quiz covers."""

    source_document: str
    """Filename of the document this quiz was generated from."""

    questions: List[Question]
    """Ordered list of Question objects."""

    quiz_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    """Unique identifier for this quiz."""

    created_at: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
    """ISO-8601 UTC timestamp of when this quiz was created."""

    def to_dict(self) -> dict:
        """Serialise to a plain Python dict (for JSON persistence)."""
        return {
            "quiz_id": self.quiz_id,
            "topic": self.topic,
            "source_document": self.source_document,
            "questions": [q.to_dict() for q in self.questions],
            "created_at": self.created_at,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Quiz":
        """Reconstruct a Quiz from a plain Python dict."""
        return cls(
            quiz_id=data["quiz_id"],
            topic=data["topic"],
            source_document=data["source_document"],
            questions=[Question.from_dict(q) for q in data["questions"]],
            created_at=data["created_at"],
        )
