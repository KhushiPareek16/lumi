"""
Document data model.

Represents a study document that has been uploaded and processed
by the DocumentService.  This object is stored in Streamlit session
state for the duration of a session — it is NOT persisted to disk.
"""

from datetime import datetime, timezone
from dataclasses import dataclass, field


@dataclass
class Document:
    """A loaded study document with its extracted plain-text content."""

    filename: str
    """Original filename of the uploaded file."""

    content: str
    """Full plain-text content extracted from the file."""

    topic: str
    """Subject / topic label entered by the student."""

    uploaded_at: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
    """ISO-8601 UTC timestamp of when the document was loaded."""

    def to_dict(self) -> dict:
        """Serialise to a plain Python dict (for debugging / logging)."""
        return {
            "filename": self.filename,
            "content": self.content,
            "topic": self.topic,
            "uploaded_at": self.uploaded_at,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Document":
        """Reconstruct a Document from a plain Python dict."""
        return cls(
            filename=data["filename"],
            content=data["content"],
            topic=data["topic"],
            uploaded_at=data.get("uploaded_at", datetime.now(timezone.utc).isoformat()),
        )
