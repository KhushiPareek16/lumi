"""
Shared input validation helpers.

Each function validates one specific piece of input and raises the
appropriate custom exception if the input is invalid.  On success
the function returns without raising anything.

These helpers are imported by services and the UI so that validation
logic is never duplicated.
"""

from exceptions.errors import (
    DocumentNotLoadedError,
    UnsupportedFileTypeError,
    FileTooLargeError,
    InvalidQuestionError,
)

# Maximum allowed upload size: 5 MB
MAX_FILE_SIZE_BYTES: int = 5 * 1024 * 1024

# Supported file extensions
SUPPORTED_EXTENSIONS: tuple[str, ...] = (".txt", ".pdf", ".docx")

# Minimum acceptable question length (characters)
MIN_QUESTION_LENGTH: int = 3

# Quiz question count bounds
MIN_QUIZ_QUESTIONS: int = 1
MAX_QUIZ_QUESTIONS: int = 20


def validate_file_extension(filename: str) -> None:
    """
    Raise UnsupportedFileTypeError if *filename* does not end with a
    supported extension (.txt, .pdf, .docx).
    """
    lower = filename.lower()
    if not any(lower.endswith(ext) for ext in SUPPORTED_EXTENSIONS):
        raise UnsupportedFileTypeError(
            f"'{filename}' is not supported. "
            f"Please upload a .txt, .pdf, or .docx file."
        )


def validate_file_size(file_bytes: bytes) -> None:
    """
    Raise FileTooLargeError if the file content exceeds MAX_FILE_SIZE_BYTES.
    """
    if len(file_bytes) > MAX_FILE_SIZE_BYTES:
        mb = len(file_bytes) / (1024 * 1024)
        raise FileTooLargeError(
            f"File is {mb:.1f} MB. Maximum allowed size is 5 MB."
        )


def validate_question_text(text: str) -> None:
    """
    Raise InvalidQuestionError if *text* is empty or shorter than
    MIN_QUESTION_LENGTH characters.
    """
    if not text or len(text.strip()) < MIN_QUESTION_LENGTH:
        raise InvalidQuestionError(
            "Question must be at least 3 characters long."
        )


def validate_topic_name(name: str) -> None:
    """
    Raise ValueError if *name* is blank or whitespace-only.
    """
    if not name or not name.strip():
        raise ValueError("Topic name must not be empty.")


def validate_num_questions(n: int) -> None:
    """
    Raise ValueError if *n* is outside the range [MIN_QUIZ_QUESTIONS, MAX_QUIZ_QUESTIONS].
    """
    if not isinstance(n, int) or n < MIN_QUIZ_QUESTIONS or n > MAX_QUIZ_QUESTIONS:
        raise ValueError(
            f"Number of quiz questions must be between "
            f"{MIN_QUIZ_QUESTIONS} and {MAX_QUIZ_QUESTIONS}."
        )


def validate_document_loaded(document: object) -> None:
    """
    Raise DocumentNotLoadedError if *document* is None.
    Call this before any operation that requires an active document.
    """
    if document is None:
        raise DocumentNotLoadedError(
            "No study material loaded. Please upload a document first."
        )


def validate_study_time(hours: float) -> None:
    """
    Raise ValueError if *hours* is not a positive number.
    """
    if not isinstance(hours, (int, float)) or hours <= 0:
        raise ValueError("Study time must be a positive number of hours.")


def validate_revision_days(days: int) -> None:
    """
    Raise ValueError if *days* is not a positive integer.
    """
    if not isinstance(days, int) or days <= 0:
        raise ValueError("Number of revision days must be a positive integer.")
