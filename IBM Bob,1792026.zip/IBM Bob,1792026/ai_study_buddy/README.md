# AI Study Buddy

A beginner-friendly AI-powered study assistant built with Python, Streamlit, and Ollama.

## Features

- Upload study notes (`.txt`, `.pdf`, `.docx`)
- Ask questions about your uploaded material
- Get simplified "Explain Like I'm 10" explanations
- Generate interactive multiple-choice quizzes with scoring
- Generate a personalised revision plan
- View history of past quizzes and revision plans

## Prerequisites

1. **Python 3.10+**
2. **Ollama** installed and running locally — download from https://ollama.com
3. A model pulled in Ollama, e.g.:
   ```
   ollama pull llama3
   ```

## Setup

```bash
# 1. Clone / navigate to this folder
cd ai_study_buddy

# 2. Create and activate a virtual environment (recommended)
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

# 3. Install dependencies
pip install -r requirements.txt
```

## Configuration

The app uses Ollama locally — **no API key is required**.

If you want to use a different Ollama model, set the environment variable before running:

```bash
# Windows PowerShell
$env:OLLAMA_MODEL = "mistral"

# macOS/Linux
export OLLAMA_MODEL=mistral
```

The default model is `llama3`.

Make sure Ollama is running (`ollama serve`) before starting the app.

## Running the App

```bash
streamlit run app.py
```

The app opens automatically in your browser at http://localhost:8501.

## Running Tests

```bash
pytest tests/ -v
```

## Project Structure

```
ai_study_buddy/
├── app.py                   # Streamlit UI entry point
├── requirements.txt
├── README.md
├── models/                  # Data classes (Document, Quiz, RevisionPlan, Topic)
├── services/                # Business logic (AI, Document, Quiz, Revision)
├── storage/                 # JSON persistence
├── utils/                   # Shared validators
├── exceptions/              # Custom exception classes
├── tests/                   # pytest unit tests
└── data/                    # Auto-created; stores history.json
```
