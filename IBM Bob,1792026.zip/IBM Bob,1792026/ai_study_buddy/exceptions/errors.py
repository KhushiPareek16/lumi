"""
Custom exception classes for AI Study Buddy.

Each exception corresponds to a specific failure scenario so that
callers can catch and handle errors precisely instead of using
broad bare `except Exception` blocks.
"""


class DocumentNotLoadedError(Exception):
    """Raised when the student tries to use an AI feature before uploading a document."""


class UnsupportedFileTypeError(Exception):
    """Raised when an uploaded file has an extension that is not .txt, .pdf, or .docx."""


class EmptyDocumentError(Exception):
    """Raised when a file is uploaded but no readable text can be extracted from it."""


class FileTooLargeError(Exception):
    """Raised when an uploaded file exceeds the maximum allowed size (5 MB)."""


class NoTopicsSelectedError(Exception):
    """Raised when revision-plan generation is attempted with an empty topic list."""


class InvalidQuestionError(Exception):
    """Raised when the student submits a question that is empty or too short."""


class AIServiceError(Exception):
    """Raised when the Ollama API call fails or returns an unusable response."""


class InvalidQuizFormatError(Exception):
    """Raised when the AI returns quiz content that cannot be parsed into the expected JSON structure."""
