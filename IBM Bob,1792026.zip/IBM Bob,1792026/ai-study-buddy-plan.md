# AI Study Buddy — Implementation Plan

## Top-Level Overview

**Goal:** Build a beginner-friendly AI-powered Study Buddy web app using Python, Streamlit, and Ollama (local LLM). Students can upload study notes, ask questions about them, get simplified explanations, take interactive multiple-choice quizzes, and generate a personalised revision plan. Quizzes and revision plans are persisted to a local JSON file so history survives between sessions.

**Scope:**
- Document upload and text extraction (.txt, .pdf, .docx)
- AI question answering grounded in the uploaded document
- "Explain Like I'm 10" mode toggle
- Interactive multiple-choice quiz with scoring
- Basic revision plan generation
- History view (previously saved quizzes and revision plans)
- Local JSON persistence

**Out of Scope:** Authentication, databases, RAG/vector search, multi-user support, payment, advanced analytics.

**Key Design Decisions:**
- LLM: Ollama running locally (e.g. `llama3` model). No API key required.
- Quiz format: Multiple-choice, 4 options, one correct answer. Student selects answers in-app and receives a score.
- Persistence: Single `history.json` file in a `data/` folder.
- One active document per session.
- Streamlit handles all UI. Business logic lives in services. AI calls live in a dedicated AI service. Document processing is separate.

---

## Folder Structure

```
ai_study_buddy/
│
├── app.py                        # Streamlit entry point
│
├── models/
│   ├── __init__.py
│   ├── document.py               # Document data model
│   ├── quiz.py                   # Quiz and Question data models
│   ├── revision_plan.py          # RevisionPlan data model
│   └── topic.py                  # Topic data model
│
├── services/
│   ├── __init__.py
│   ├── document_service.py       # File reading and text extraction
│   ├── ai_service.py             # All Ollama/LLM interactions
│   ├── quiz_service.py           # Quiz creation and scoring logic
│   └── revision_service.py      # Revision plan creation logic
│
├── storage/
│   ├── __init__.py
│   └── persistence.py            # Load/save history.json
│
├── utils/
│   ├── __init__.py
│   └── validators.py             # Shared input validation helpers
│
├── exceptions/
│   ├── __init__.py
│   └── errors.py                 # All custom exception classes
│
├── data/
│   └── history.json              # Auto-created; persists quizzes and plans
│
├── tests/
│   ├── test_document_service.py
│   ├── test_ai_service.py
│   ├── test_quiz_service.py
│   ├── test_revision_service.py
│   ├── test_persistence.py
│   └── test_validators.py
│
├── requirements.txt
└── README.md
```

---

## Sub-Tasks

---

### Sub-Task 1 — Project Scaffold and Dependencies

**Intent:** Create the folder structure, empty module files, `requirements.txt`, and `README.md` so every subsequent sub-task has a clean place to work.

**Expected Outcomes:**
- All folders and `__init__.py` files exist.
- `requirements.txt` lists all required packages.
- `data/history.json` initialised as an empty JSON object.
- `README.md` contains a one-paragraph project description and setup instructions.

**Todo List:**
1. Create the folder tree above.
2. Add empty `__init__.py` to `models/`, `services/`, `storage/`, `utils/`, `exceptions/`, `tests/`.
3. Create `requirements.txt` with: `streamlit`, `ollama`, `pypdf2` (or `pdfplumber`), `python-docx`, `pytest`.
4. Create `data/history.json` initialised as `{"quizzes": [], "revision_plans": []}`.
5. Write `README.md` with project description, prerequisites (Ollama installed, model pulled), and `streamlit run app.py` startup instruction.

**Relevant Context:** No existing code. This is the starting point for all other sub-tasks.

**Status:** [ ] pending

---

### Sub-Task 2 — Custom Exceptions

**Intent:** Define all custom exception classes in one place so every layer of the app can import and raise meaningful errors instead of generic Python exceptions.

**Expected Outcomes:**
- `exceptions/errors.py` contains all custom exception classes.
- Each exception has a clear docstring explaining when it is raised.

**Todo List:**
1. Create `exceptions/errors.py`.
2. Define the following exception classes, all inheriting from `Exception`:
   - `DocumentNotLoadedError` — raised when a student tries to use AI features before uploading a document.
   - `UnsupportedFileTypeError` — raised when the uploaded file is not `.txt`, `.pdf`, or `.docx`.
   - `EmptyDocumentError` — raised when the file is uploaded but contains no extractable text.
   - `FileTooLargeError` — raised when the uploaded file exceeds the size limit (5 MB).
   - `NoTopicsSelectedError` — raised when revision plan generation is attempted with no topics.
   - `InvalidQuestionError` — raised when the student submits an empty or too-short question.
   - `AIServiceError` — raised when the Ollama API call fails or returns an unusable response.
   - `InvalidQuizFormatError` — raised when the AI returns a quiz response that cannot be parsed into the expected structure.

**Relevant Context:** These exceptions will be imported and raised throughout `services/` and caught in `app.py`.

**Status:** [ ] pending

---

### Sub-Task 3 — Data Models

**Intent:** Define plain Python dataclasses (or simple classes) for all data objects the app works with. These classes hold data only — no business logic.

**Expected Outcomes:**
- `models/document.py` — `Document` class defined.
- `models/topic.py` — `Topic` class defined.
- `models/quiz.py` — `Question` and `Quiz` classes defined.
- `models/revision_plan.py` — `RevisionPlan` class defined.
- All models support serialisation to and from a plain Python `dict` for JSON persistence.

**Todo List:**
1. Create `models/document.py` with class `Document`:
   - Fields: `filename: str`, `content: str`, `topic: str`, `uploaded_at: str` (ISO timestamp).
   - Method: `to_dict()` and `from_dict()` for serialisation.

2. Create `models/topic.py` with class `Topic`:
   - Fields: `name: str`, `added_at: str` (ISO timestamp).
   - Method: `to_dict()` and `from_dict()`.

3. Create `models/quiz.py` with two classes:
   - `Question`: Fields: `question_text: str`, `options: list[str]` (exactly 4), `correct_answer: str` (one of the 4 options), `explanation: str` (brief explanation of the correct answer).
   - `Quiz`: Fields: `quiz_id: str` (UUID), `topic: str`, `source_document: str` (filename), `questions: list[Question]`, `created_at: str`.
   - Both support `to_dict()` and `from_dict()`.

4. Create `models/revision_plan.py` with class `RevisionPlan`:
   - Fields: `plan_id: str` (UUID), `topics: list[str]`, `schedule: str` (plain text plan from LLM), `created_at: str`.
   - Support `to_dict()` and `from_dict()`.

**Relevant Context:** `Quiz` and `RevisionPlan` are saved to `data/history.json` by `storage/persistence.py`. `Document` lives only in Streamlit session state — it is not persisted.

**Status:** [ ] pending

---

### Sub-Task 4 — Validators

**Intent:** Centralise all input validation so services and UI can call a single helper rather than duplicating guard logic.

**Expected Outcomes:**
- `utils/validators.py` contains standalone validation functions.
- Each function raises the appropriate custom exception on failure and returns cleanly on success.

**Todo List:**
1. Create `utils/validators.py`.
2. Implement `validate_file_type(filename: str)` — raises `UnsupportedFileTypeError` if extension is not `.txt`, `.pdf`, or `.docx`.
3. Implement `validate_file_size(file_bytes: bytes)` — raises `FileTooLargeError` if size exceeds 5 MB.
4. Implement `validate_question_text(text: str)` — raises `InvalidQuestionError` if text is empty or fewer than 3 characters.
5. Implement `validate_topic_name(name: str)` — raises `ValueError` if name is blank or whitespace-only.
6. Implement `validate_num_questions(n: int)` — raises `ValueError` if n is not between 1 and 20 inclusive.
7. Implement `validate_document_loaded(document)` — raises `DocumentNotLoadedError` if document is `None`.

**Relevant Context:** Imported by `document_service.py`, `quiz_service.py`, `revision_service.py`, and `app.py`.

**Status:** [ ] pending

---

### Sub-Task 5 — Document Service

**Intent:** Handle all file reading and text extraction logic, completely separated from the UI.

**Expected Outcomes:**
- `services/document_service.py` can load a `.txt`, `.pdf`, or `.docx` file and return a populated `Document` object.
- Raises appropriate custom exceptions for bad files.

**Todo List:**
1. Create `services/document_service.py` with class `DocumentService`.
2. Implement `load_document(file_obj, topic: str) -> Document`:
   - Calls `validate_file_type()` and `validate_file_size()` before processing.
   - Dispatches to the correct extraction method based on file extension.
   - After extraction, raises `EmptyDocumentError` if content is empty or whitespace-only.
   - Returns a populated `Document` instance.
3. Implement `_extract_txt(file_obj) -> str` — reads plain text.
4. Implement `_extract_pdf(file_obj) -> str` — uses `pdfplumber` to extract text page by page. If no text is extracted (scanned image PDF), raises `EmptyDocumentError`.
5. Implement `_extract_docx(file_obj) -> str` — uses `python-docx` to extract paragraph text.
6. Implement `truncate_content(content: str, max_chars: int = 12000) -> str` — trims content to fit within a reasonable LLM context window, preserving whole sentences where possible.

**Relevant Context:** `load_document` receives the raw file object from Streamlit's `st.file_uploader`. `truncate_content` is called by `ai_service.py` before building prompts.

**Status:** [ ] pending

---

### Sub-Task 6 — AI Service

**Intent:** Encapsulate every interaction with Ollama into a single service. The rest of the app never calls Ollama directly — it always goes through this service.

**Expected Outcomes:**
- `services/ai_service.py` contains class `AIService` with methods for all four AI features.
- Prompts are constructed inside this service using the designs in the Prompt Design section below.
- Raises `AIServiceError` on any Ollama failure.

**Todo List:**
1. Create `services/ai_service.py` with class `AIService`.
2. Constructor accepts `model_name: str = "llama3"` and stores it.
3. Implement private helper `_call_ollama(prompt: str) -> str`:
   - Calls `ollama.chat()` with the given prompt.
   - Wraps any exception in `AIServiceError`.
   - Returns the response content string.
4. Implement `answer_question(document: Document, question: str, eli10: bool) -> str`:
   - Builds the Q&A prompt (see Prompt Design).
   - Calls `_call_ollama`.
   - Returns the answer string.
5. Implement `explain_concept(document: Document, concept: str, eli10: bool) -> str`:
   - Builds the explanation prompt.
   - Calls `_call_ollama`.
   - Returns the explanation string.
6. Implement `generate_quiz(document: Document, num_questions: int) -> list[dict]`:
   - Builds the quiz generation prompt (see Prompt Design).
   - Calls `_call_ollama`.
   - Parses the response as JSON into a list of question dicts.
   - Raises `InvalidQuizFormatError` if the JSON cannot be parsed or is malformed.
   - Returns the raw list of dicts (QuizService wraps them into model objects).
7. Implement `generate_revision_plan(topics: list[str], document: Document) -> str`:
   - Builds the revision plan prompt.
   - Calls `_call_ollama`.
   - Returns the plan as a plain text string.

**Relevant Context:** Uses `Document.content` (after truncation). Uses the `ollama` Python package. See Prompt Design section below for the exact prompt templates.

**Status:** [ ] pending

---

### Sub-Task 7 — Quiz Service

**Intent:** Coordinate quiz creation and scoring. Calls `AIService` to get raw question data, wraps it into model objects, and provides scoring logic for interactive quizzes.

**Expected Outcomes:**
- `services/quiz_service.py` contains class `QuizService`.
- Can create, save, and score quizzes.

**Todo List:**
1. Create `services/quiz_service.py` with class `QuizService(ai_service: AIService, persistence)`.
2. Implement `create_quiz(document: Document, num_questions: int) -> Quiz`:
   - Calls `validate_document_loaded()` and `validate_num_questions()`.
   - Calls `ai_service.generate_quiz()` to get raw question dicts.
   - Converts each dict into a `Question` object.
   - Creates and returns a `Quiz` object with a UUID, timestamp, and source document name.
3. Implement `save_quiz(quiz: Quiz)`:
   - Calls `persistence.save_quiz(quiz)`.
4. Implement `score_quiz(quiz: Quiz, answers: dict[int, str]) -> dict`:
   - `answers` is a mapping of question index to the student's selected option string.
   - Compares each answer to `question.correct_answer`.
   - Returns a dict: `{"score": int, "total": int, "results": list[bool]}`.

**Relevant Context:** `answers` dict is built in `app.py` from Streamlit radio button selections.

**Status:** [ ] pending

---

### Sub-Task 8 — Revision Service

**Intent:** Coordinate revision plan generation. Calls `AIService` and wraps the result into a `RevisionPlan` model object.

**Expected Outcomes:**
- `services/revision_service.py` contains class `RevisionService`.
- Can create and save revision plans.

**Todo List:**
1. Create `services/revision_service.py` with class `RevisionService(ai_service: AIService, persistence)`.
2. Implement `create_revision_plan(topics: list[str], document: Document) -> RevisionPlan`:
   - Raises `NoTopicsSelectedError` if `topics` is empty.
   - Calls `ai_service.generate_revision_plan()`.
   - Wraps the result in a `RevisionPlan` object with UUID and timestamp.
   - Returns the `RevisionPlan`.
3. Implement `save_plan(plan: RevisionPlan)`:
   - Calls `persistence.save_plan(plan)`.

**Relevant Context:** Topics are collected from Streamlit text input in `app.py`.

**Status:** [ ] pending

---

### Sub-Task 9 — Persistence Layer

**Intent:** Provide a simple load/save interface for `history.json` so no other module needs to know about file I/O or JSON serialisation.

**Expected Outcomes:**
- `storage/persistence.py` contains class `Persistence`.
- `data/history.json` is created automatically if it does not exist.
- Quizzes and revision plans can be saved and loaded reliably.

**Todo List:**
1. Create `storage/persistence.py` with class `Persistence`.
2. Constructor sets `filepath = "data/history.json"`.
3. Implement `_load() -> dict` — reads and returns the JSON file; if missing, creates it with `{"quizzes": [], "revision_plans": []}` and returns that.
4. Implement `_save(data: dict)` — writes the dict to the JSON file with indentation.
5. Implement `save_quiz(quiz: Quiz)`:
   - Loads current data, appends `quiz.to_dict()`, saves back.
6. Implement `save_plan(plan: RevisionPlan)`:
   - Loads current data, appends `plan.to_dict()`, saves back.
7. Implement `get_quizzes() -> list[Quiz]`:
   - Loads data, converts each dict back to a `Quiz` object using `Quiz.from_dict()`.
   - Returns the list in reverse-chronological order (newest first).
8. Implement `get_plans() -> list[RevisionPlan]`:
   - Loads data, converts each dict back to a `RevisionPlan` object.
   - Returns the list in reverse-chronological order.

**Relevant Context:** Called by `QuizService.save_quiz()`, `RevisionService.save_plan()`, and directly by `app.py` for the history view.

**Status:** [ ] pending

---

### Sub-Task 10 — Streamlit UI

**Intent:** Build the full user-facing interface in `app.py` using Streamlit. The UI calls services and models — it contains no business logic of its own.

**Expected Outcomes:**
- Running `streamlit run app.py` starts the app.
- All six main features are accessible via a sidebar navigation menu.
- Session state manages the active document and ELI10 toggle.
- All errors are caught and displayed to the student as friendly messages using `st.error()`.

**Todo List:**

1. Create `app.py`. Initialise Streamlit session state keys at the top:
   - `st.session_state.document` — active `Document` or `None`.
   - `st.session_state.eli10` — bool, default `False`.
   - `st.session_state.topics` — list of topic strings, default `[]`.
   - `st.session_state.current_quiz` — active `Quiz` or `None`.
   - `st.session_state.quiz_answers` — dict of student's in-progress answers.

2. Build a **sidebar** with:
   - App title and description.
   - Navigation radio/selectbox with pages: `Upload Document`, `Ask a Question`, `Explain Concept`, `Generate Quiz`, `Revision Plan`, `History`.
   - ELI10 toggle (`st.toggle` or `st.checkbox`) that updates `st.session_state.eli10`.
   - Display the name of the currently loaded document (or "No document loaded").

3. **Page: Upload Document**
   - `st.file_uploader` for `.txt`, `.pdf`, `.docx`.
   - Topic/subject text input.
   - On upload: calls `DocumentService.load_document()`, stores result in session state, shows success message and a preview of the first 500 characters.
   - On error: catches custom exceptions and shows `st.error()` with a user-friendly message.

4. **Page: Ask a Question**
   - Guard: show a warning if no document is loaded.
   - `st.text_area` for the student's question.
   - Submit button calls `AIService.answer_question()`.
   - Displays answer with `st.markdown()`.
   - Shows ELI10 badge if mode is active.

5. **Page: Explain Concept**
   - Guard: show warning if no document is loaded.
   - `st.text_input` for the concept to explain.
   - Submit button calls `AIService.explain_concept()`.
   - Displays explanation. Shows ELI10 badge if active.

6. **Page: Generate Quiz**
   - Guard: show warning if no document is loaded.
   - `st.number_input` for number of questions (1–20).
   - "Generate Quiz" button calls `QuizService.create_quiz()`, stores in session state, saves via `QuizService.save_quiz()`.
   - Renders each question with `st.radio()` for option selection (stored in `st.session_state.quiz_answers`).
   - "Submit Quiz" button calls `QuizService.score_quiz()` and displays the score.
   - After scoring, reveals the correct answer and explanation for each question using `st.expander()`.

7. **Page: Revision Plan**
   - Guard: show warning if no document is loaded.
   - `st.text_input` to add a topic; "Add Topic" button appends to `st.session_state.topics`.
   - Displays the current topic list with remove buttons.
   - "Generate Revision Plan" button calls `RevisionService.create_revision_plan()` and saves it.
   - Displays the generated plan with `st.markdown()`.

8. **Page: History**
   - Calls `Persistence.get_quizzes()` and `Persistence.get_plans()`.
   - Shows "No history yet" if both lists are empty.
   - Each quiz shown in an `st.expander` with its topic, date, number of questions.
   - Each revision plan shown in an `st.expander` with its topics and full schedule text.

**Relevant Context:** `app.py` imports and instantiates `DocumentService`, `AIService`, `QuizService`, `RevisionService`, `Persistence`. All service instances are cached with `@st.cache_resource` to avoid re-initialising on every Streamlit rerun.

**Status:** [ ] pending

---

### Sub-Task 11 — Unit Tests

**Intent:** Write unit tests for all service and utility modules. Tests use mocking to avoid real Ollama calls, real file I/O where appropriate, and real JSON writes.

**Expected Outcomes:**
- All tests pass with `pytest` from the project root.
- Coverage covers happy paths and all custom exception raise paths.

**Todo List:**
1. `tests/test_validators.py`:
   - Test each validator with valid input (no exception raised).
   - Test each validator with invalid input (correct exception raised).

2. `tests/test_document_service.py`:
   - Test `.txt` extraction returns correct `Document`.
   - Test `.pdf` extraction (mock `pdfplumber`).
   - Test `.docx` extraction (mock `python-docx`).
   - Test `UnsupportedFileTypeError` for `.jpg`.
   - Test `FileTooLargeError` for oversized content.
   - Test `EmptyDocumentError` for blank content.
   - Test `truncate_content` respects max_chars.

3. `tests/test_ai_service.py`:
   - Mock `ollama.chat` to return a fixed response string.
   - Test `answer_question` builds prompt and returns expected output.
   - Test `generate_quiz` correctly parses a valid JSON response.
   - Test `generate_quiz` raises `InvalidQuizFormatError` on bad JSON.
   - Test `_call_ollama` wraps Ollama exceptions in `AIServiceError`.

4. `tests/test_quiz_service.py`:
   - Mock `AIService.generate_quiz` to return a fixed list of question dicts.
   - Test `create_quiz` returns a `Quiz` with correct number of `Question` objects.
   - Test `score_quiz` returns correct score for a set of answers.
   - Test `score_quiz` correctly identifies wrong answers.

5. `tests/test_revision_service.py`:
   - Mock `AIService.generate_revision_plan` to return a fixed string.
   - Test `create_revision_plan` returns a `RevisionPlan` with correct topics and schedule.
   - Test `NoTopicsSelectedError` raised for empty topic list.

6. `tests/test_persistence.py`:
   - Use `tmp_path` (pytest fixture) to write to a temp directory.
   - Test that `history.json` is created automatically if missing.
   - Test `save_quiz` and `get_quizzes` round-trip correctly.
   - Test `save_plan` and `get_plans` round-trip correctly.
   - Test `get_quizzes` returns newest first.

**Relevant Context:** All tests use `unittest.mock.patch` or `pytest-mock` for isolation. No real Ollama or file system dependency in unit tests except persistence (which uses `tmp_path`).

**Status:** [ ] pending

---

## Prompt Design

These are the prompt templates `AIService` will use. Prompts follow a system + user message pattern compatible with `ollama.chat()`.

---

### Q&A Prompt

```
System:
You are a helpful study assistant. Answer the student's question using ONLY the
provided study material. If the answer is not found in the material, say so clearly.
[IF ELI10]: Explain your answer as if the student is 10 years old, using simple
words, short sentences, and a fun analogy if possible.

User:
--- STUDY MATERIAL ---
{document.content}
--- END OF MATERIAL ---

Question: {question}
```

---

### Explain Concept Prompt

```
System:
You are a patient tutor. Explain the concept using ONLY information from the
provided study material. Be clear and concise.
[IF ELI10]: Explain as if the student is 10 years old. Use a simple analogy.

User:
--- STUDY MATERIAL ---
{document.content}
--- END OF MATERIAL ---

Concept to explain: {concept}
```

---

### Quiz Generation Prompt

```
System:
You are a quiz generator. Generate exactly {num_questions} multiple-choice questions
based ONLY on the provided study material.

Return your response as a valid JSON array and nothing else. No explanation, no
markdown fences. Use this exact structure:
[
  {
    "question_text": "...",
    "options": ["A. ...", "B. ...", "C. ...", "D. ..."],
    "correct_answer": "A. ...",
    "explanation": "Brief explanation of why this is correct."
  }
]

User:
--- STUDY MATERIAL ---
{document.content}
--- END OF MATERIAL ---
```

---

### Revision Plan Prompt

```
System:
You are a study planner. Create a simple day-by-day revision plan for a student
based ONLY on the topics and study material provided. Keep it practical, clear,
and encouraging. Format the plan as plain text with a section for each day.

User:
Topics to revise: {comma-separated topics}

--- STUDY MATERIAL ---
{document.content}
--- END OF MATERIAL ---
```

---

## Dependencies

| Package | Purpose |
|---|---|
| `streamlit` | Web UI framework |
| `ollama` | Python client for Ollama local LLM |
| `pdfplumber` | PDF text extraction |
| `python-docx` | .docx text extraction |
| `pytest` | Unit testing |
| `pytest-mock` | Mocking in tests (optional, `unittest.mock` is built-in) |

---

## Step-by-Step Implementation Order

Implement sub-tasks in this order. Each sub-task builds on the previous ones:

1. **Sub-Task 1** — Project scaffold (folders, empty files, requirements.txt)
2. **Sub-Task 2** — Custom exceptions (no dependencies)
3. **Sub-Task 3** — Data models (depends on exceptions)
4. **Sub-Task 4** — Validators (depends on exceptions)
5. **Sub-Task 5** — Document service (depends on models, validators, exceptions)
6. **Sub-Task 6** — AI service (depends on models, exceptions, prompts)
7. **Sub-Task 7** — Quiz service (depends on AI service, models, validators)
8. **Sub-Task 8** — Revision service (depends on AI service, models)
9. **Sub-Task 9** — Persistence layer (depends on models)
10. **Sub-Task 10** — Streamlit UI (depends on all services and persistence)
11. **Sub-Task 11** — Unit tests (depends on everything above)
